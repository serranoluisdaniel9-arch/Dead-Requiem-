# APK real v0.9 vs. proyecto reconstruido

Documento de referencia sobre qué se recuperó del APK real y en qué se diferenciaba
la reconstrucción anterior (basada únicamente en el transcript del MHTML).

---

## 1. Integridad del artefacto

| Propiedad | Valor |
|---|---|
| Fichero | `dead-strike-reborn-v0.9.apk` |
| Tamaño | 1.157.581 bytes (1,10 MiB) |
| SHA-256 | `11fcf3875f23610feb03c1a17d01cd31be22b7b1432b90e4ebf99df9309bde8e` |
| MD5 | `e186184c07c3ff4a8f25a3d6967adbc6` |
| Tipo | Android package (APK), con APK Signing Block |
| Ficheros internos | 35 |

## 2. Firma

No hay `keytool` ni `apksigner` en el sandbox; el certificado se extrajo del bloque
PKCS#7 (`META-INF/DISTRITO.RSA`) con `openssl`.

| Campo | Valor |
|---|---|
| Subject | `CN = Distrito 09 Prototype` |
| Issuer | `CN = Distrito 09 Prototype` (autofirmado) |
| Validez | 26 oct 2026 07:11:36 → 23 oct 2036 07:11:36 GMT |
| Nº de serie | `383824E6FDDE0947` |
| Huella SHA-256 | `C2:1C:66:EC:C2:3D:E2:89:F7:1A:32:DC:D4:60:2D:81:A4:A5:84:65:C5:4C:96:B4:50:00:8D:85:1E:57:13:72` |
| Esquemas de firma | v2 y v3 (`X-Android-APK-Signed: 2, 3`) |
| Alias de keystore | `DISTRITO` |

**Es una clave de prototipo autofirmada, no una clave de distribución.** El nombre del
certificado `Distrito 09 Prototype` coincide con el keystore documentado en el
transcript original. No sirve para publicar en Google Play y no debe reutilizarse
para una release real: Play exige una clave de subida propia y, además, la huella
de esta clave ya está expuesta en este documento.

## 3. Identidad declarada en `AndroidManifest.xml`

El manifest se decodificó con un parser AXML propio (formato binario de Android, no
es XML legible directamente en el APK).

| Campo | Valor |
|---|---|
| `package` | `dev.distrito09.game` |
| `versionCode` | **12** |
| `versionName` | **0.9** |
| `label` | `Dead Strike Reborn` |
| `minSdkVersion` | 26 (Android 8.0) |
| `targetSdkVersion` | 35 (Android 15) |
| `compileSdkVersion` | 35 |
| `glEsVersion` | `0x20000` (OpenGL ES 2.0), requerido |
| `screenOrientation` | 6 → `sensorLandscape` |
| `allowBackup` | `false` |
| `usesCleartextTraffic` | `false` |
| `hardwareAccelerated` | `true` |
| **Permisos** | **ninguno** |
| Actividad | `.MainActivity`, `exported=true` |

Confirmado: cero permisos declarados. El juego no toca red, almacenamiento externo
ni ubicación. `allowBackup=false` evita que el perfil local se sincronice.

## 4. Contenedor Android (`classes.dex`)

`classes.dex` pesa solo 5.572 bytes y contiene una única clase útil,
`dev.distrito09.game.MainActivity`, más su clase anónima `MainActivity$1`
(el `WebViewClient`). El wrapper no contiene lógica de juego: solo sirve assets.

Extraído de las cadenas del dex:

- Origen cargado: `https://appassets.androidplatform.net/assets/index.html?touch=1`
  → usa `WebViewAssetLoader`, no `file://`.
- `shouldInterceptRequest` sirve desde `AssetManager` con MIME explícito:
  `text/html`, `text/javascript`, `text/css`, `image/png`, `text/plain`.
- Cabeceras `Cache-Control: no-cache` en las respuestas.
- Códigos `Forbidden` / `Not Found` para rutas fuera de `/assets/`.
- `setAllowFileAccess` / `setAllowContentAccess` (desactivados),
  `setDomStorageEnabled`, `setJavaScriptEnabled`, `setMediaPlaybackRequiresUserGesture`.
- `onBackPressed` despacha al JS: si la fase es `shop` emite el evento
  `distrito-back`; si es `playing` o `paused` pulsa `#pause`.
- D8 versión `8.6.2-dev`, `min-api: 26`, modo `debug`.

**Hallazgo relevante — desajuste real en el APK:** el Java llama
`window.__gameState().phase`, es decir, invoca `__gameState` **como función**. Pero
`game.js` lo asigna como **objeto**:

```js
window.__gameState = state;   // líneas 337 y 815
```

`state` es una función, así que `window.__gameState()` sí funciona… salvo que lo
importante es que el wrapper depende de ese símbolo global. Cualquier refactor que
lo elimine rompe el botón atrás de Android. Está documentado como riesgo en el
README, no "arreglado", porque es el comportamiento que tenía el build real.

## 5. Assets reales

`assets/` contiene el juego completo: **3.744 líneas** de JS/CSS/HTML escritas a mano,
más Three.js vendorizado.

| Fichero | Líneas | Bytes |
|---|---|---|
| `game.js` | 824 | 55.503 |
| `character-models.js` | 504 | 35.455 |
| `shop-ui.js` | 466 | 21.160 |
| `mission-world.js` | 270 | 12.232 |
| `joystick-editor.js` | 248 | 9.830 |
| `street-detail.js` | 189 | 8.933 |
| `economy-rules.js` | 184 | 6.633 |
| `aim-rules.js` | 144 | 6.421 |
| `mission-rules.js` | 138 | 5.315 |
| `wave-rules.js` | 138 | 5.109 |
| `combat-rules.js` | 62 | 2.386 |
| `joystick-settings.js` | 49 | 1.782 |
| `controls-settings.js` | 30 | 978 |
| `index.html` | 67 | 11.036 |
| `style.css` | 50 | 30.168 |
| `shop.css` | 247 | 13.691 |
| `joystick.css` | 134 | 3.357 |
| `vendor/three.module.js` | — | 1.244 KB |
| `vendor/THREE-LICENSE.txt` | — | MIT, © 2010-2023 three.js authors |

Three.js **r160** confirmado (`REVISION = '160'`), vendorizado y no cargado desde CDN:
el juego funciona sin red.

## 6. Diferencias contra la reconstrucción anterior

La reconstrucción se hizo solo con el transcript, que **no contenía código**. Todos
los ficheros divergían. Recuento de líneas cambiadas (`diff -u`, líneas `+`/`-`):

| Fichero | Real | Reconstruido | Líneas distintas |
|---|---|---|---|
| `game.js` | 824 | 1.471 | **2.067** |
| `character-models.js` | 504 | 392 | 818 |
| `shop-ui.js` | 466 | 348 | 721 |
| `style.css` | 50 | 623 | 588 |
| `shop.css` | 247 | 260 | 443 |
| `mission-world.js` | 270 | 232 | 437 |
| `street-detail.js` | 189 | 260 | 392 |
| `economy-rules.js` | 184 | 254 | 374 |
| `aim-rules.js` | 144 | 212 | 295 |
| `joystick.css` | 134 | 141 | 227 |
| `mission-rules.js` | 138 | 133 | 226 |
| `wave-rules.js` | 138 | 125 | 220 |
| `index.html` | 67 | 144 | 175 |
| `combat-rules.js` | 62 | 85 | 123 |
| `joystick-settings.js` | 49 | 82 | 92 |

**Módulos que existían en el APK y faltaban por completo en la reconstrucción:**

- **`joystick-editor.js`** (248 líneas) — editor visual de tamaño y posición del
  joystick. La reconstrucción solo tenía un panel de ajustes estático; el real
  permite arrastrar el mando por pantalla con lienzo de fondo.
- **`controls-settings.js`** (30 líneas) — módulo puro de normalización y persistencia
  de sensibilidad (`distrito09.controls.v1`), con `look` 30–180 y `aim` 20–150 en
  pasos de 5. En la reconstrucción esa lógica estaba incrustada en `game.js`.

**Nada existía solo en la reconstrucción**: no había módulos inventados de más, sino
implementaciones distintas de los mismos contratos.

### Diferencias de fondo, no solo de líneas

- **`index.html` real es 67 líneas frente a 144.** El real es denso: una línea por
  bloque, sin formatear. El reconstruido estaba expandido y con textos distintos.
- **`style.css` real es 50 líneas y 30 KB**, frente a 623 líneas y 11 KB. El original
  usa líneas larguísimas; es el mismo diseño, escrito en formato comprimido. No es
  que falte CSS: está todo, en menos líneas.
- **`game.js` real es más pequeño** (824 vs 1.471) porque el módulo de controles está
  extraído aparte y porque el original usa un estilo de una-línea-por-bloque.
- **El real expone `window.__gameState`** con un objeto de diagnóstico enorme
  (posición, enemigos, oleadas, munición, misión, perfil, recursos del renderer).
  La reconstrucción no lo tenía: era imposible deducirlo del transcript.
- **Valores de tuning que la reconstrucción acertó** (el transcript sí los detallaba):
  daño 45/90, cargadores 12/6, pitch −70°/+75°, 60 cr por extracción, +20 por
  suministros, R-6 a 150, skins 75/90/110, Renacida 110, zonas en z 20/−25/−62.
- **Valores que la reconstrucción inventó y el real corrige:** la tabla de enemigos es
  `shambler 90 / runner 90 / resistant 180 / brute 270` HP (la reconstrucción usaba
  100/100/200/300), y la munición de recogida es de 4 y 5 balas en posiciones
  concretas (`ammo-east` en 7.8/22, `aid-west` en −8/−5, `ammo-west` en −8.1/−58).

## 7. Qué sigue sin ser original

| Elemento | Estado |
|---|---|
| Todos los `.js`, `.css`, `index.html` de `assets/` | **Originales del APK**, byte a byte |
| `vendor/three.module.js` + licencia | **Originales del APK** |
| Iconos y recursos `res/` | **Originales del APK** |
| `AndroidManifest.binary.xml` | **Original del APK** (binario, sin decodificar a propósito) |
| `MainActivity.java` | **Reconstruido** — el APK solo trae `classes.dex` compilado; el fuente no viaja en el APK. Se infiere de las cadenas del dex y puede no coincidir con el original línea a línea |
| `build-apk.sh` | **Reconstruido** — nunca viajó en el APK y nunca se ha ejecutado contra un SDK real |
| `.gitignore`, scripts auxiliares | Reconstruidos |

El código fuente Java del wrapper **no es recuperable** de un APK: solo existe
compilado a DEX. Cualquier `MainActivity.java` que se obtenga de un APK es
necesariamente una reconstrucción (o el resultado de un decompilador, que produce
Java aproximado, no el fuente original).
