"""Diagnostic probe: where do the draw calls actually come from?

Not part of the harness. Run it when the draw-call budget needs explaining:
it walks the live scene graph and groups every visible mesh by name prefix and
by material, so the biggest families are obvious instead of guessed.

Run:  python3 tests/probe.py
"""
import json
import sys

from playwright.sync_api import sync_playwright

BASE = 'http://127.0.0.1:8099/index.html'
GL = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']

PROBE = '''() => {
  const scene = window.__sceneRef;
  const groups = {};
  let meshes = 0, instanced = 0, instances = 0;
  const byMaterial = {};
  scene.traverse(o => {
    if (!o.isMesh && !o.isSprite && !o.isLine) return;
    if (!o.visible) return;
    let p = o, hidden = false;
    while (p) { if (!p.visible) { hidden = true; break; } p = p.parent; }
    if (hidden) return;
    meshes++;
    if (o.isInstancedMesh) { instanced++; instances += o.count; }
    const key = o.name || (o.isInstancedMesh ? 'instanced-unnamed' : o.isSprite ? 'sprite' : 'unnamed');
    groups[key] = (groups[key] || 0) + 1;
    const m = o.material;
    const mk = m ? (m.name || m.type) + ':' + (m.color ? m.color.getHexString() : '-') : 'none';
    byMaterial[mk] = (byMaterial[mk] || 0) + 1;
  });
  const top = Object.entries(groups).sort((a, b) => b[1] - a[1]).slice(0, 18);
  const mats = Object.entries(byMaterial).sort((a, b) => b[1] - a[1]).slice(0, 18);
  return { meshes, instanced, instances, top, mats,
           render: window.__gameState().renderer,
           resources: window.__gameState().visuals.resources };
}'''


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(args=GL)
        page = browser.new_context(viewport={'width': 1280, 'height': 720}).new_page()
        page.goto(BASE + '?debug=1', wait_until='load')
        page.wait_for_function('() => window.__gameState', timeout=30000)
        page.wait_for_function("() => !document.getElementById('start').disabled", timeout=20000)
        page.click('#start')
        page.wait_for_function("() => window.__gameState().phase === 'playing'", timeout=20000)
        page.evaluate('() => window.__debugAdvance(0.5)')
        data = page.evaluate(PROBE)
        print(json.dumps(data, indent=2))
        browser.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
