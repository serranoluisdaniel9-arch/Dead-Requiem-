"""Headless verification for Dead Strike Reborn v1.4.

Drives the real page in Chromium (software GL), exercises the run loop, buys a
new v1.2 weapon, its ammo and an attachment through the actual shop buttons,
forces all three falling-zombie outcomes, checks the graphics refactor (single
recycled lamp, instanced blob shadows, depth fog) and the draw-call budget,
then reloads and opens a second browser context to prove the profile persists.

Run:  python3 tests/verify.py            (expects a static server on :8099)
Exit: 0 when every check passes.
"""
import json
import sys

from playwright.sync_api import sync_playwright

BASE = 'http://127.0.0.1:8099/index.html'
GL = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']

results = []


def check(name, ok, detail=''):
    results.append((name, bool(ok), detail))
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f'  — {detail}' if detail else ''))


def attach(page, errors, failed):
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    page.on('pageerror', lambda e: errors.append(f'PAGEERROR {e}'))
    page.on('requestfailed',
            lambda r: failed.append(f'{r.url.split("/")[-1]}: {r.failure}'))


def start_run(page):
    page.wait_for_function("() => !document.getElementById('start').disabled", timeout=20000)
    page.evaluate('''() => {
      for (const id of ['paused', 'shop', 'route', 'joystick-editor']) {
        document.getElementById(id)?.classList.add('hidden');
      }
    }''')
    page.click('#start')
    page.wait_for_function("() => window.__gameState && window.__gameState().phase === 'playing'",
                           timeout=20000)


def open_shop(page):
    page.evaluate('''() => {
      for (const id of ['paused', 'route', 'joystick-editor']) {
        document.getElementById(id)?.classList.add('hidden');
      }
    }''')
    page.evaluate("() => document.getElementById('intro-shop').click()")
    page.wait_for_function("() => window.__gameState().phase === 'shop'", timeout=10000)


def buy(page, kind, item_id):
    """Clicks the real shop button for one card and returns the new profile.

    The shop is tabbed, so the card's panel has to be selected first — a hidden
    button is still in the DOM but cannot be clicked.
    """
    tab_index = {'ammo': 0, 'weapon': 1, 'attachment': 2, 'skin': 3}[kind]
    page.evaluate(f"() => document.querySelectorAll('.shop-tab')[{tab_index}].click()")
    page.wait_for_timeout(250)
    selector = f'button[data-shop-action][data-kind="{kind}"][data-id="{item_id}"]'
    page.wait_for_selector(selector, state='visible', timeout=10000)
    page.eval_on_selector(selector, 'el => el.click()')
    page.wait_for_timeout(800)
    return page.evaluate('() => window.__gameState().profile')


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(args=GL)
        context = browser.new_context(viewport={'width': 1280, 'height': 720})
        page = context.new_page()
        errors, failed = [], []
        attach(page, errors, failed)

        page.goto(BASE + '?debug=1', wait_until='load')
        page.wait_for_function("() => window.__gameState", timeout=30000)

        boot = page.evaluate('() => window.__gameState()')
        check('no console errors on boot', not errors, f'{len(errors)}: {errors[:3]}')
        check('no failed requests on boot', not failed, f'{len(failed)}: {failed[:3]}')
        check('version is 1.4', boot.get('version') == '1.4', boot.get('version'))

        # --- graphics refactor -------------------------------------------------
        gfx = page.evaluate('''() => {
          const s = window.__gameState();
          return {
            fog: window.__fogInfo ? window.__fogInfo() : null,
            render: s.renderer,
            blob: s.visuals.blobShadows,
            shadowMap: s.visuals.shadowMap,
          };
        }''')
        check('depth fog is linear with a real near/far pair',
              bool(gfx['fog']) and gfx['fog']['type'] == 'Fog' and gfx['fog']['far'] > 60,
              json.dumps(gfx['fog']))
        check('blob shadows are one instanced field',
              bool(gfx['fog']) and gfx['fog']['blobDrawCalls'] == 1,
              f"drawCalls={gfx['fog']['blobDrawCalls'] if gfx['fog'] else '?'} capacity={gfx['fog']['blobCapacity'] if gfx['fog'] else '?'}")
        check('street lighting is one recycled PointLight',
              bool(gfx['fog']) and gfx['fog']['pointLights'] == 1 and gfx['fog']['lamps'] == 12,
              f"pointLights={gfx['fog']['pointLights']} lamps={gfx['fog']['lamps']}")

        start_run(page)
        page.wait_for_timeout(400)
        run = page.evaluate('() => window.__gameState()')
        check('run starts with 36 enemies', run['enemies'] == 36, run['enemies'])
        check('pistol starts 12/18', run['ammo'] == 12 and run['reserve'] == 18,
              f"{run['ammo']}/{run['reserve']}")
        check('blob shadows cover player + 36 enemies', run['visuals']['blobShadows'] == 37,
              run['visuals']['blobShadows'])
        check('shadow map stays off on touch', run['visuals']['shadowMap'] is True,
              'desktop context: full shadow map on, blob shadows still instanced')

        # --- draw calls --------------------------------------------------------
        # v1.4: measure a real frame synchronously. Reading the counter after a
        # wall-clock wait returns a stale frame on software GL.
        frame = page.evaluate('() => window.__debugRenderOnce()')
        check('draw calls under 150', frame['calls'] < 150, f"calls={frame['calls']}")
        # Gather the crowd first: at spawn nobody is within the LOD radius, so a
        # bare frame would report zero instanced bodies and prove nothing.
        page.evaluate('() => window.__debugGather(6)')
        page.evaluate('() => window.__debugAdvance(0.3)')
        crowd = page.evaluate('() => window.__debugRenderOnce()')
        check('zombie bodies are instanced, not per-mesh',
              crowd['batches'] <= 40 and crowd['instances'] > 0 and crowd['bodies'] > 0,
              f"batches={crowd['batches']} instances={crowd['instances']} bodies={crowd['bodies']}")
        check('the worst case (every zombie on screen) stays under 200 draws',
              crowd['calls'] < 200, f"calls={crowd['calls']}")

        # --- v1.3 graphics: textures, atmosphere, quality ----------------------
        v13 = page.evaluate('''() => {
          const s = window.__gameState();
          const scene = window.__sceneRef;
          // Count how many instanced batches actually carry an albedo map, and
          // how many distinct texture images the scene uses.
          let mapped = 0, batches = 0, textured = 0;
          const images = new Set();
          scene.traverse(o => {
            if (!o.isMesh) return;
            const m = o.material;
            if (!m || Array.isArray(m)) return;
            if (o.isInstancedMesh) batches++;
            if (m.map) {
              mapped++;
              if (m.map.image) images.add(m.map.image);
              if (m.bumpMap) textured++;
            }
          });
          const city = scene.getObjectByName('destroyed-city');
          return {
            mapped, batches, textured, textures: images.size,
            cityInstances: city ? city.children.reduce((a, c) => a + (c.count || 0), 0) : 0,
            cityDraws: city ? city.children.length : 0,
            atmosphere: s.atmosphere,
            quality: s.quality,
            destroyed: s.destroyedCity,
            merge: s.missionMerge,
            fogLayers: scene.getObjectByName('volumetric-fog')?.children.length || 0,
            dust: scene.getObjectByName('floating-dust')?.geometry.attributes.position.count || 0,
          };
        }''')
        check('facades and road carry procedural albedo + bump maps',
              v13['mapped'] >= 8 and v13['textured'] >= 8,
              f"mapped={v13['mapped']} withBump={v13['textured']} textures={v13['textures']}")
        check('destroyed-city layer is instanced, not per-prop meshes',
              v13['cityInstances'] > 400 and v13['cityDraws'] <= 20,
              f"instances={v13['cityInstances']} draws={v13['cityDraws']}")
        check('volumetric fog layers and dust field are live',
              v13['fogLayers'] >= 3 and v13['dust'] >= 90,
              f"fogLayers={v13['fogLayers']} dust={v13['dust']}")
        check('colour grade is applied', v13['atmosphere']['grade'] > 0,
              v13['atmosphere'])
        check('quality preset is a real preset, not a label',
              v13['quality']['id'] in ('low', 'medium', 'high', 'ultra') and v13['quality']['fogLayers'] >= 3,
              v13['quality'])
        check('mission props were merged by material',
              v13['merge']['after'] < v13['merge']['before'],
              f"{v13['merge']['before']} meshes -> {v13['merge']['after']} draws")

        # --- movement / aiming / shooting -------------------------------------
        before = page.evaluate('() => window.__gameState().position')
        page.keyboard.down('w')
        page.evaluate('() => window.__debugAdvance(1.2)')
        page.keyboard.up('w')
        after = page.evaluate('() => window.__gameState().position')
        check('W walks forward (z decreases)', after[2] < before[2] - 1,
              f'{before[2]:.2f} -> {after[2]:.2f}')

        page.keyboard.press('c')
        page.evaluate('() => window.__debugAdvance(0.6)')
        aimed = page.evaluate('() => window.__gameState().fov')
        check('aiming narrows FOV', aimed < 50, f'fov={aimed:.1f}')
        page.keyboard.press('c')
        page.evaluate('() => window.__debugAdvance(0.4)')

        page.evaluate('() => window.__debugTeleport(0, 40)')
        page.evaluate('() => window.__debugAdvance(0.2)')
        page.keyboard.press('Space')
        page.evaluate('() => window.__debugAdvance(0.3)')
        shot = page.evaluate('() => window.__gameState().lastShot')
        check('shooting registers a shot', shot is not None,
              shot['impact'] if shot else 'none')

        # --- falling zombies: all three outcomes ------------------------------
        falls = page.evaluate('''() => {
          for (const outcome of ['dead', 'enraged', 'crawler']) {
            window.__debugForceFall(outcome);
          }
          window.__debugAdvance(2.0);
          const landed = window.__debugLandAll();
          return { landed, stats: window.__gameState().falls };
        }''')
        by_outcome = {e['outcome']: e for e in falls['landed']}
        check('fall outcome "dead" resolves correctly',
              by_outcome.get('dead', {}).get('dead') is True,
              json.dumps(by_outcome.get('dead')))
        check('fall outcome "enraged" resolves correctly',
              by_outcome.get('enraged', {}).get('damageMul', 1) > 1.2,
              json.dumps(by_outcome.get('enraged')))
        check('fall outcome "crawler" resolves correctly',
              by_outcome.get('crawler', {}).get('prone') is True,
              json.dumps(by_outcome.get('crawler')))
        check('all three fall outcomes were counted',
              all(falls['stats'].get(k, 0) >= 1 for k in ('dead', 'enraged', 'crawler')),
              json.dumps({k: falls['stats'].get(k) for k in ('dead', 'enraged', 'crawler')}))

        # --- v1.4 physics: falls are driven by height, not a dice roll --------
        phys = page.evaluate("""() => {
          const out = {};
          // A 15 m drop must kill; a 5 m drop must not.
          window.__debugForceFallHeight(15, 0.5);
          window.__debugForceFallHeight(5, 0.5);
          window.__debugAdvance(3.0);
          out.landed = window.__debugLandAll();
          out.pop = window.__debugPopulation();
          return out;
        }""")
        tall = [e for e in phys['landed'] if e['outcome'] == 'dead']
        short = [e for e in phys['landed'] if e['outcome'] != 'dead']
        check('a 15 m fall kills on impact', len(tall) >= 1, json.dumps(tall[:1]))
        check('a 5 m fall does not kill', len(short) >= 1, json.dumps(short[:1]))
        # The v1.3 bug: a body that fell spinning stood up and walked on its side.
        spun = [e for e in phys['landed'] if not e['dead']]
        check('no survivor keeps a fall spin (walks upright)',
              all(abs(e['rotationZ']) < 0.01 for e in spun),
              json.dumps([{'id': e['id'], 'rotZ': e['rotationZ']} for e in spun[:3]]))
        check('a corpse lies on its side, not standing',
              all(abs(e['rotationZ'] - 1.55) < 0.01 for e in tall),
              json.dumps([{'id': e['id'], 'rotZ': e['rotationZ']} for e in tall[:3]]))
        check('a crawler is prone and low',
              all(e['prone'] and e['y'] < 0.4 for e in phys['landed'] if e['outcome'] == 'crawler'),
              json.dumps([{'id': e['id'], 'y': e['y']} for e in phys['landed'] if e['outcome'] == 'crawler'][:3]))

        # --- v1.4 collisions: no body inside a collider ----------------------
        coll = page.evaluate("""() => {
          const cols = window.__debugColliders();
          const pop = window.__debugPopulation();
          const bad = [];
          for (const e of pop) {
            if (e['falling']) continue;
            for (const c of cols) {
              if (Math.abs(e.x - c.x) < c.rx + 0.18 && Math.abs(e.z - c.z) < c.rz + 0.18) {
                bad.push({id: e.id, x: e.x, z: e.z, cx: c.x, cz: c.z});
                break;
              }
            }
          }
          return {total: pop.length, inside: bad.length, sample: bad.slice(0, 3)};
        }""")
        check('no zombie is inside a collider', coll['inside'] == 0,
              f"inside={coll['inside']}/{coll['total']} {json.dumps(coll['sample'])}")

        # --- v1.4: a prone body must not walk --------------------------------
        prone = page.evaluate("""() => {
          const pop = window.__debugPopulation();
          const cr = pop.find(e => e.prone);
          if (!cr) return {none: true};
          const before = {x: cr.x, z: cr.z};
          window.__debugAdvance(2.0);
          const after = window.__debugPopulation().find(e => e.id === cr.id);
          return {id: cr.id, before, after: after ? {x: after.x, z: after.z, prone: after.prone} : null};
        }""")
        if prone.get('none'):
            check('a prone crawler does not walk upright', False, 'no crawler in the population')
        else:
            moved = abs(prone['after']['x'] - prone['before']['x']) + abs(prone['after']['z'] - prone['before']['z'])
            check('a prone crawler does not walk upright',
                  prone['after']['prone'] and moved < 3.0,
                  f"moved={moved:.2f} m in 2 s, prone={prone['after']['prone']}")

        # --- v1.4 AI: cone, occlusion, hearing -------------------------------
        ai = page.evaluate("""() => ({
          front: window.__debugVision({x: 0, z: 0}, 0, {x: 0, z: 10}),
          behind: window.__debugVision({x: 0, z: 0}, 0, {x: 0, z: -10}),
          side: window.__debugVision({x: 0, z: 0}, 0, {x: 10, z: 0}),
          loud: window.__debugHearing({x: 0, z: 0}, {x: 0, z: 20}, 1),
          quiet: window.__debugHearing({x: 0, z: 0}, {x: 0, z: 20}, 0.2),
          silent: window.__debugHearing({x: 0, z: 0}, {x: 0, z: 1}, 0),
        })""")
        check('vision sees straight ahead', ai['front'] > 0.4, ai['front'])
        check('vision is blind behind', ai['behind'] == 0, ai['behind'])
        check('vision is blind at 90 degrees', ai['side'] == 0, ai['side'])
        check('hearing carries a loud shot', ai['loud'] > 0, ai['loud'])
        check('hearing ignores a suppressed shot at range', ai['quiet'] == 0, ai['quiet'])
        check('hearing ignores silence', ai['silent'] == 0, ai['silent'])

        # --- v1.4 graphics profiles + frame cap ------------------------------
        prof = page.evaluate("""() => {
          const out = {};
          for (const q of ['low', 'medium', 'high', 'ultra']) {
            out[q] = null;
          }
          out.current = window.__debugPerf();
          out.fps30 = window.__debugSetFps(30);
          out.fps60 = window.__debugSetFps(60);
          return out;
        }""")
        check('four graphics profiles exist', prof['current']['quality']['id'] in ('low', 'medium', 'high', 'ultra'),
              prof['current']['quality']['id'])
        check('the frame cap is settable at runtime', prof['fps30'] == 30 and prof['fps60'] == 60,
              f"30->{prof['fps30']} 60->{prof['fps60']}")
        check('rain and smoke are live at this preset',
              prof['current']['weather']['rain'] >= 0 and prof['current']['weather']['smoke'] >= 0,
              json.dumps(prof['current']['weather']))

        # --- v1.4: the frame limiter really throttles ------------------------
        throttle = page.evaluate("""() => {
          window.__debugSetFps(30);
          const t0 = performance.now();
          let drawn = 0;
          // 60 synthetic 16.7 ms frames: a 30 fps cap must draw about half.
          for (let i = 0; i < 60; i++) {
            if (window.__debugShouldRender(16.7)) drawn++;
          }
          window.__debugSetFps(60);
          return {drawn, ms: performance.now() - t0};
        }""")
        check('a 30 fps cap draws about half the frames',
              26 <= throttle['drawn'] <= 34, f"drawn={throttle['drawn']}/60")

        # --- shop: new weapon, its ammo, an attachment ------------------------
        # Give the run a wallet so the purchases test the shop, not the grind.
        page.evaluate('''() => {
          const raw = JSON.parse(localStorage.getItem('distrito09.profile.v4') || '{}');
          raw.credits = 6000;
          raw.version = 4;
          localStorage.setItem('distrito09.profile.v4', JSON.stringify(raw));
        }''')
        # A reload while the software-GL loop is running can stall the navigation,
        # so leave the page first and come back — same storage, clean load.
        # v1.3: `about:blank` itself timed out because the previous page's render
        # loop was still saturating the single-threaded software rasteriser. Stop
        # the loop first, then navigate.
        page.evaluate("() => { window.__stopLoop && window.__stopLoop(); }")
        page.wait_for_timeout(300)
        page.goto('about:blank', wait_until='commit', timeout=60000)
        page.goto(BASE + '?debug=1&quality=low', wait_until='domcontentloaded', timeout=60000)
        page.wait_for_function("() => window.__gameState", timeout=30000)
        open_shop(page)

        cards = page.evaluate("() => document.querySelectorAll('button[data-shop-action]').length")
        check('shop renders a card per weapon, skin, ammo line and attachment',
              cards >= 30, f'{cards} cards')

        profile = buy(page, 'weapon', 'burst')
        check('new v1.2 weapon bought (Ráfaga B-3)', 'burst' in profile['ownedWeapons'],
              profile['ownedWeapons'])

        profile = buy(page, 'ammo', 'burst')
        check('new weapon ammo bought with its own stock', profile['ammo']['burst'] > 0,
              f"rounds={profile['ammo']['burst']}")

        profile = buy(page, 'attachment', 'optic')
        check('attachment bought and owned', 'optic' in profile['ownedAttachments'],
              profile['ownedAttachments'])

        profile = buy(page, 'attachment', 'optic')
        mounted = profile['attachments'].get('burst', [])
        check('attachment mounted on the equipped weapon', 'optic' in mounted,
              json.dumps(profile['attachments']))

        resolved = page.evaluate('() => window.__gameState().attachments.resolved')
        check('mounted attachment changes the resolved stats', resolved['aimRange'] > 40,
              f"aimRange={resolved['aimRange']}")

        # --- persistence ------------------------------------------------------
        # Same reason as above: stop the render loop before navigating, or the
        # software rasteriser keeps the navigation from ever settling.
        page.evaluate("() => { window.__stopLoop && window.__stopLoop(); }")
        page.wait_for_timeout(300)
        page.goto('about:blank', wait_until='commit', timeout=60000)
        page.goto(BASE + '?debug=1&quality=low', wait_until='domcontentloaded', timeout=60000)
        page.wait_for_function("() => window.__gameState", timeout=30000)
        reloaded = page.evaluate('() => window.__gameState().profile')
        check('profile survives a page reload',
              'burst' in reloaded['ownedWeapons'] and reloaded['ammo']['burst'] > 0,
              f"weapons={reloaded['ownedWeapons']} ammo={reloaded['ammo']['burst']}")
        check('mounted attachment survives the reload',
              'optic' in reloaded['attachments'].get('burst', []),
              json.dumps(reloaded['attachments']))

        # A brand-new context has its own storage: nothing should leak across.
        # The first page is closed first — two live software-GL contexts in one
        # browser starve each other and the second navigation never settles.
        page.close()
        context.close()
        fresh = browser.new_context(viewport={'width': 1280, 'height': 720})
        fresh_page = fresh.new_page()
        fresh_errors = []
        attach(fresh_page, fresh_errors, [])
        fresh_page.goto(BASE + '?debug=1', wait_until='domcontentloaded')
        fresh_page.wait_for_function("() => window.__gameState", timeout=30000)
        clean = fresh_page.evaluate('() => window.__gameState().profile')
        check('a separate browser context has its own empty profile',
              clean['credits'] == 0 and clean['ownedAttachments'] == [],
              f"credits={clean['credits']} attachments={clean['ownedAttachments']}")
        check('no console errors in the fresh context', not fresh_errors, str(fresh_errors[:2]))

        check('no console errors overall', not errors, f'{len(errors)}: {errors[:3]}')
        check('no failed requests overall', not failed, f'{len(failed)}: {failed[:3]}')

        browser.close()

    passed = sum(1 for _, ok, _ in results if ok)
    print(f'\n{passed}/{len(results)} checks passed')
    return 0 if passed == len(results) else 1


if __name__ == '__main__':
    sys.exit(main())
