# Dead Strike Reborn — v1.4 (base: APK real v0.9)

Proyecto reconstruido **a partir del APK compilado**, no del transcript. Todo el
código del juego que hay aquí es el original del build v0.9, extraído byte a byte
del APK y verificado funcionando en navegador. La v1.0 añadió las diez mejoras de
jugabilidad; la v1.1 zombis que caen, tres armas más, acoples y la nueva pantalla
de inicio; la v1.2 bajó los draw calls y compiló el primer APK real; la v1.3 fue
la pasada gráfica profunda; la **v1.4** arregla la física de las caídas, reescribe
la IA de percepción, instancia los cuerpos por pieza y añade perfiles gráficos
con Ultra y límite de FPS.

| | |
|---|---|
| Paquete | `dev.distrito09.game` |
| versionName / versionCode | **1.4 / 17** (el APK base era 0.9 / 12) |
| Origen | `dead-strike-reborn-v0.9.apk` (1.157.581 bytes) |
| SHA-256 del APK base | `11fcf3875f23610feb03c1a17d01cd31be22b7b1432b90e4ebf99df9309bde8e` |
| Firma | `CN = Distrito 09 Prototype`, autofirmada, esquemas v2 + v3 |
| Motor | Three.js **r160** vendorizado (MIT) |
| Permisos Android | **ninguno** |

---

## Qué cambió en v1.4

### El motor: se queda en Three.js, y por qué

Se evaluó migrar a Babylon.js, PlayCanvas o un pipeline glTF con assets reales.
**No se migró.** Los criterios, con los números de este proyecto:

| Criterio | Three.js (actual) | Migrar |
|---|---|---|
| Tamaño del bundle | 1,4 MB de APK, 30 módulos JS | Babylon ~4 MB extra; PlayCanvas exige su editor y un runtime propio |
| Rendimiento móvil | 110–166 draw calls medidos, GL por software | Ninguno de los dos es más rápido por sí mismo: el coste es la escena, no el motor |
| Compatibilidad con el código | 30 módulos, ~9.000 líneas, solver de animación propio | Todo el rig, el solver, la economía y la tienda habría que reescribirlos |
| Tiempo de migración | — | Semanas, con el juego roto entre medias |
| Riesgo | — | Alto: se perdería la verificación de 55 comprobaciones |

El techo real no era el motor: era que 37 cuerpos costaban 9 mallas cada uno.
Eso se arregló con instancing, no cambiando de motor.

### Física de zombis: el bug que los hacía caminar tumbados

`landFalling()` ponía el resultado de la caída pero **nunca limpiaba
`group.rotation.z`**, que la caída había estado girando. Un zombi que caía
girando se levantaba y caminaba *de lado*: el solver de pose era correcto, el
transform raíz estaba obsoleto. El mismo fallo dejaba a un arrastrado con el
radio de colisión y la velocidad de pie.

Ahora todo pasa por un contrato único (`zombie-physics.js`):

- **El resultado lo decide la altura**, no un dado: <6 m casi siempre sobrevive,
  6–11 m lo decide la tirada, >11 m muere. Una caída de 15 m ya no puede producir
  un arrastrado.
- **`rootTransform()` siempre devuelve `rotationZ` explícito**, así que un giro
  de caída no puede sobrevivir a un cambio de estado.
- **`locomotionFor()`** dice si un estado puede trasladarse: un cadáver, un
  cuerpo cayendo y uno levantándose no se mueven; un arrastrado va al 34 % y con
  radio 0,30.
- **`separateFromColliders()`** empuja fuera a cualquier cuerpo que haya acabado
  dentro de un colisionador (spawn, empujón, aterrizaje).

### IA: cono, oclusión, audición, memoria y roles

La v1.3 tenía una línea: `dist<17 && dot>.15`. Un cono de 160° sin prueba de
oclusión — un zombi mirando a una pared te veía a través de ella.

- **Visión** de 70° con caída por ángulo y distancia, y línea de visión contra
  los mismos colisionadores que usan las balas.
- **Audición** por radio de ruido: un silenciador se oye cerca, una escopeta
  lejos. El ruido decae; un disparo es un momento, no un faro permanente.
- **Memoria**: al perderte, busca orbitando tu última posición conocida, y si
  pasa 9 s sin nada, vuelve a casa.
- **Estados**: idle → suspicious → investigate → chase → search → idle, con
  `alert` 0..1 persistente.
- **Roles**: acechadores que esperan dentro de un edificio y salen al acercarte,
  corredores que flanquean, y cobardes que huyen al ser heridos y vuelven.
- **Alerta compartida**: uno que te ve despierta a los que tiene al lado.

### Gráficos: draw calls 182 → 110–123

El techo eran los personajes. La solución no fue fusionar el rig (los muslos y
las pantorrillas giran por separado) sino **instanciar por pieza**: se conserva
la jerarquía de pivotes y el solver, y cada pieza copia su matriz de mundo a un
`InstancedMesh` por (arquetipo, pieza).

- **8 arquetipos → 4**: las variantes solo cambian la paleta, así que el tinte va
  por instancia en vez de por geometría.
- **9 lotes por arquetipo → 5**: las piezas que comparten geometría y material
  (ambos muslos, ambos brazos) van en el mismo buffer.
- **El LOD lejano también se instancia**: 36 zombis lejanos eran 36 draws, ahora
  son 4.
- **Props de misión**: fusionados como un solo grupo con color horneado por
  vértice — 59 mallas → 7 draws.

Medido con un frame síncrono real: **110 (bajo) / 123 (alto) / 132 (ultra)** de
base, y **144 / 157 / 166** con los 36 zombis en pantalla a la vez.

### Clima y superficies mojadas

La v1.3 tenía `rainCount = 0`: el buffer existía y nunca se llenaba, así que la
lluvia del README era código muerto. Ahora es real: un `LineSegments` de rayas
inclinadas recicladas alrededor del jugador, densidad por preset. Las superficies
mojadas son un cambio de material (rugosidad 0,34 y metalness 0,16 en asfalto y
acera), no un filtro: por eso la luz de las farolas se estira en una mancha
vertical. Y hay humo subiendo de los restos.

### Perfiles gráficos y FPS

Cuatro presets reales — **Bajo, Medio, Alto, Ultra** — que cambian mapa de
sombras (0/1024/2048/4096), sombras, pixel ratio, capas de niebla, polvo, lluvia,
humo, anisotropía, tamaño de textura, densidad de escombros y distancia de LOD.
Más un **límite de 30 / 60 / 120 FPS** que se aplica en vivo: la simulación sigue
corriendo a la tasa real y solo se limita el dibujado, así que un tope de 30 no
convierte el juego en cámara lenta.

Ambos se guardan en `localStorage` y se aplican al recargar. También por URL:
`?quality=low|medium|high|ultra&fps=30|60|120`.

---

|---|
| Paquete | `dev.distrito09.game` |
| versionName / versionCode | **1.3 / 16** (el APK base era 0.9 / 12) |
| Origen | `dead-strike-reborn-v0.9.apk` (1.157.581 bytes) |
| SHA-256 del APK base | `11fcf3875f23610feb03c1a17d01cd31be22b7b1432b90e4ebf99df9309bde8e` |
| Firma | `CN = Distrito 09 Prototype`, autofirmada, esquemas v2 + v3 |
| Motor | Three.js **r160** vendorizado (MIT) |
| Permisos Android | **ninguno** |

---

## Qué cambió en v1.3

### Gráficos

**Texturas procedurales** (`procedural-textures.js`). Seis familias —asfalto,
hormigón, ladrillo, metal oxidado, madera y yeso— pintadas en canvas al arrancar,
cada una con albedo, mapa de relieve y mapa de rugosidad. Cero assets externos.
El ruido es determinista (LCG con semilla por familia), así que dos ejecuciones
dibujan exactamente la misma textura.

> **El fallo que costó encontrar.** El color del material *multiplica* el albedo.
> Un tinte `#283039` sobre un asfalto ya oscuro daba ~0,03 de albedo: la calle se
> veía negra y plana por mucha textura que llevara. Lo mismo en las fachadas, con
> un gris 0,44 sobre un ladrillo 0,4. Los tintes ahora son claros y la textura
> aporta el tono. Medido sobre captura: la desviación típica de la calle pasó de
> **2,6 a 17,8** y la de una pared de **4,7 a 25,6**.

**Ciudad devastada** (`environment-detail.js`). 627 instancias en 15 draw calls:
fachadas con ventanas reventadas y marcos partidos, secciones de muro colapsadas
con forjados a la vista, cinco vehículos abandonados (calcinados, furgoneta
volcada, turismos), tres contenedores con corrugación y barras de cierre, dos
farolas caídas, cables en catenaria entre fachadas, escombros, tablones, neumáticos
y nueve baches con borde oscuro.

**Atmósfera** (`atmosphere.js`). Siete capas de niebla volumétrica simulada
(planos grandes con alfa radial, deriva independiente), 420 motas de polvo en un
`Points` reciclado alrededor del jugador, y un grade de color a pantalla completa
—viñeteado más separación de tonos frío/cálido— dibujado como un quad extra, no
como filtro CSS (un filtro CSS sobre el canvas obliga al compositor a releer el
framebuffer entero cada frame en Android).

**Iluminación cinematográfica.** Luna fría direccional con sombras (2,35), rebote
cálido de calle (0,75), hemisférica cielo frío / suelo cálido (1,55) y contraluz
(0,55). Exposición ACES a 1,45. Las luces de emergencia ámbar son mallas
emisivas, no luces: la escena mantiene **un solo PointLight**.

**Draw calls: 182 → 145.** El recorte vino de tres sitios: los cuatro coches
héroe pasaron de ~40 mallas con material único a instancing con tinte por
instancia; los props de misión se fusionan por material (`geometry-merge.js`,
59 mallas → 35 draws); y las 12 nieblas sueltas se sustituyeron por las capas de
atmósfera.

### Cámara

La cámara estaba casi detrás de Valeria a 2,8 m: ella llenaba el centro y tapaba
la vista. Ahora va a 3,35 m, más alta y desplazada al hombro derecho (0,78 m),
con la mira apuntada 12 m por delante y desplazada con el mismo hombro, y un
*retroceso* que la saca de los colisionadores si el punto deseado cae dentro de
un edificio.

### Animación

`zombie-animation.js` resuelve ocho estados con un solver puro: caminar, correr,
caer, levantarse, arrastrarse, morir, **atacar** (embestida con ambos brazos y
torso que se echa encima) y **recibir impacto** (reculada con la cabeza
sacudiéndose). La embestida dura 0,42 s y el flinch 0,26 s, ambos como temporizadores
de un solo disparo para que el solver interpole y el bucle no contenga lógica de
pose.

### Armas y disparos

Destello de boca con núcleo aditivo, humo que se expande al desvanecerse, chispas
aditivas y humo normal-mezclado en los impactos —dos materiales distintos, no un
borrón gris— y trazadoras.

### Calidad

Tres presets reales (`QUALITY_PRESETS`), no etiquetas: cambian resolución de
shadow map (512/1024/2048), si hay sombras, ratio de píxeles (1 / 1,25 / 1,6),
capas de niebla (3/5/7), motas de polvo (90/220/420), tamaño de textura y
densidad de escombros. Se eligen en Ajustes y se guardan; se aplican al recargar.
También se puede forzar por URL con `?quality=low|medium|high`.

---

## Ejecutar

El juego usa módulos ES, así que necesita servidor HTTP (`file://` no funciona):

```bash
python3 -m http.server 8099
# abrir http://localhost:8099/index.html
```

Para simular el modo móvil del APK (controles táctiles, sombras desactivadas):

```
http://localhost:8099/index.html?touch=1
```

Ese `?touch=1` es exactamente lo que carga el wrapper Android:
`https://appassets.androidplatform.net/assets/index.html?touch=1`.

### Controles de escritorio

`WASD` / flechas mover · arrastrar ratón mirar · `Espacio` disparar ·
`R` recargar · `C` o clic derecho apuntar · `V` empujar · `F` recoger ·
`E`/`Q` girar cámara · `Esc` pausa

## Estructura

```
index.html              UI completa (intro, HUD, pausa, fin)
game.js                 bucle, cámara, render, audio, entrada (824 líneas)
aim-rules.js            pitch −70°/+75°, dirección, rayBox, asistencia de mira
combat-rules.js         tiempos de empuje, recarga, selección de objetivo
economy-rules.js        armas, skins, créditos, perfil persistente (v3)
attachments-rules.js    catálogo de acoples, compatibilidad, stats resueltos
falling-zombies.js      zonas de caída, director y tres desenlaces
mission-rules.js        misión, recogidas, 36 spawns base
wave-rules.js           3 oleadas de refuerzo, planificación de spawns
character-models.js     fábrica de personajes y zombis low-poly
mission-world.js        geometría del distrito
street-detail.js        detalle procedural de la calle
shop-ui.js / shop.css   tienda del refugio
joystick-editor.js      editor visual de joystick
joystick-settings.js    persistencia del joystick
controls-settings.js    persistencia de sensibilidad
style.css               estilos base
vendor/three.module.js  Three.js r160 + licencia MIT
assets/branding/        iconos 192 y 512 + intro-bg.jpg (arte de la intro)
android/res/            recursos del APK (iconos de lanzador)
android/AndroidManifest.binary.xml   manifest original, sin tocar
android/AndroidManifest.xml          manifest de texto para build-apk.sh (v1.1 / 14)
android/res/values/                  strings.xml y styles.xml (añadidos en v1.1)
android/MainActivity.java            RECONSTRUIDO (ver abajo)
build-apk.sh                         RECONSTRUIDO (ver abajo)
docs/REAL_VS_RECONSTRUCTED.md        comparación con la reconstrucción anterior
```

## Qué está verificado

Comprobado con Playwright + Chromium headless, WebGL por software
(`--use-gl=swiftshader`), viewport 1280×720 y también 915×412 con emulación táctil.

| Comprobación | Resultado |
|---|---|
| Sintaxis de los 15 módulos JS | 15/15 OK |
| Assets por HTTP | 200 en todos, incluido Three.js (1.272.972 B) |
| Errores de consola / `pageerror` | **0 y 0** |
| Arranque | `phase: playing`, intro oculta, HUD visible |
| Enemigos | **36 exactos** |
| Munición / reserva inicial | **12 / 18** (30 balas) con la pistola |
| Caminar con `W` | z 54 → 49,96 (**decrece**: convención −Z correcta) |
| Disparo | cargador 20 → 18 con la carabina, `lastShot.impact: "enemy"` |
| Recarga | `reloadMode: manual`, `reloadTotal: 0.8` |
| Apuntar | `aiming: true`, FOV 58 → 44 |
| Pausa | `phase: paused` |
| Cámara | jugador z 53,86 / cámara z 56,13 → **detrás**, tercera persona |
| Render por frame | ~238–243 draw calls, ~17–20 k triángulos |
| Modo `?touch=1` | `touch-device`, joystick 122 px en (0.025, 0.96), controles táctiles `block` |
| Arnés completo | **58/58** (`tests/verify.py`) |

La escena se revisó además visualmente: avatar low-poly visible de espaldas, HUD
legible sin solapes, niebla y distrito renderizados.

## Lo que el build real tiene y la reconstrucción anterior no tenía

La reconstrucción previa se hizo solo con el transcript del MHTML, que **no contenía
código**: era una reimplementación contra la especificación. El APK real la sustituye
por completo. Diferencias principales:

- **`joystick-editor.js`** (248 líneas) no existía en la reconstrucción: editor visual
  para arrastrar el joystick por pantalla.
- **`controls-settings.js`** (30 líneas) tampoco: normalización y persistencia de
  sensibilidad, que en la reconstrucción estaba incrustada en `game.js`.
- **`game.js` real es 824 líneas frente a 1.471** de la reconstrucción, y el real
  expone el hook de diagnóstico `window.__gameState`.
- **Tabla de enemigos real: 90 / 90 / 180 / 270 HP** (errante, corredor, resistente,
  bruto). La reconstrucción había puesto 100/100/200/300.
- Diferencias de líneas en todos los ficheros: `game.js` 2.067, `character-models.js`
  818, `shop-ui.js` 721, `style.css` 588.

Detalle completo en [`docs/REAL_VS_RECONSTRUCTED.md`](docs/REAL_VS_RECONSTRUCTED.md).

## Qué sigue siendo reconstruido

Estas dos piezas **no son originales** y están marcadas como tales:

### `android/MainActivity.java` — reconstruido

Un APK solo contiene `classes.dex` compilado; el fuente Java no viaja en el paquete.
Este fichero se infiere de las cadenas del dex y reproduce el comportamiento
documentado del wrapper:

- carga `https://appassets.androidplatform.net/assets/index.html?touch=1` vía
  `WebViewAssetLoader` (no `file://`)
- `shouldInterceptRequest` sirve desde `AssetManager` con MIME explícito
  (`text/html`, `text/javascript`, `text/css`, `image/png`, `text/plain`) y
  `Cache-Control: no-cache`
- `setAllowFileAccess` / `setAllowContentAccess` desactivados, `setDomStorageEnabled`
  y `setJavaScriptEnabled` activos
- `onBackPressed` despacha al JS: `distrito-back` en la tienda, `#pause` en juego

**No se puede garantizar que coincida línea a línea con el original.**

### `build-apk.sh` — reconstruido y nunca ejecutado

El script de build no viaja en el APK. La versión incluida envuelve los assets en un
WebView con `aapt` / `javac` / `d8` / `zipalign` / `apksigner`, sin Gradle, coherente
con minSdk 26 / targetSdk 35 y el `versionCode 12` observados. **No se ha ejecutado
nunca contra un SDK de Android real**, así que hay que tratarlo como plantilla.

## Riesgos y rarezas encontrados

- **Dependencia frágil del hook `window.__gameState`.** El Java del APK lo llama como
  función (`window.__gameState().phase`); `game.js` lo asigna a la función `state`,
  así que funciona. Si alguien refactoriza y lo elimina o lo convierte en un objeto,
  el botón atrás de Android deja de responder. No está "arreglado" a propósito:
  es el comportamiento del build real.
- **Sombras desactivadas en táctil.** `renderer.shadowMap.enabled = !touch`. En el
  APK, que siempre es táctil, las sombras nunca se encienden: por eso los objetos
  parecen flotar. En escritorio sin `?touch=1` sí se activan. Es una decisión de
  rendimiento del original, no un fallo de la extracción.
- **Niebla exponencial a 0,0385** con color de fondo `#bdc3bd`: la escena se ve
  lavada a partir de ~40 m. Coincide con la dirección de arte documentada, pero
  también es el motivo de que el distrito parezca plano.
- **Audio sintetizado, no muestreado.** Solo hay `AudioContext` con osciladores
  (`sawtooth` + filtro `lowpass`) y un `createBufferSource`: el sonido es generado,
  no hay ficheros de audio en el APK. Es lo esperado en 1,1 MB de APK.
- **Clave de firma de prototipo.** `CN = Distrito 09 Prototype` es autofirmada y su
  huella SHA-256 está publicada en `docs/REAL_VS_RECONSTRUCTED.md`. No sirve para
  Play y no debe reutilizarse para una release.

## v1.0 — qué cambió sobre el APK v0.9

Diez mejoras implementadas sobre el árbol real, sin tocar el original. Todo lo de
abajo está verificado por `tests/verify.py` (39/39 comprobaciones en Chromium headless).

### 1. Audio procedural (`audio-engine.js`)

Fuera los osciladores de onda cuadrada. Todo se sintetiza en un `AudioContext`:
ruido filtrado para el cuerpo de cada disparo, un `ConvolverNode` con impulso de
ruido decreciente para la reverb corta de calle, y `StereoPannerNode` por voz.

| Sonido | Síntesis |
|---|---|
| Disparo | burst lowpass (cuerpo por arma) + triángulo grave (retumbe) |
| Impacto | lowpass corto en carne / highpass en mundo + seno descendente |
| Recarga | tres clics bandpass (cargador fuera, dentro, corredera) |
| Pasos | lowpass 700→180 Hz, más suave al apuntar |
| Ambiente | retumbe <120 Hz + viento bandpass 620 Hz con LFO a 0,07 Hz |
| Gruñido | sierra 58→36 Hz, paneado por posición relativa al jugador |

El paneo de zombis usa `panFor()`: proyecta el vector enemigo sobre el eje derecho
de la cámara, así que **un gruñido por detrás se oye por detrás**.

### 2. Blob shadows (`feedback.js`)

Plano con textura radial (`CanvasTexture` 128×128, degradado de 0,72 a 0) bajo cada
personaje y enemigo, con `polygonOffset` para no pelear con el asfalto. **37 sombras
activas** (jugador + 36 enemigos), también en táctil. El shadow map completo sigue
apagado en táctil: `renderer.shadowMap.enabled = !touch`.

### 3. Feedback de impacto

Hitmarker de cuatro ticks (ámbar al matar), número de daño flotante proyectado a
pantalla, flash blanco de un frame en el enemigo golpeado (`emissive`), y
micro-sacudida de cámara de 2–3 px con decaimiento de 0,18 s.

### 4. Oleadas escalonadas

Cada oleada introduce **un** arquetipo y conserva los anteriores como relleno:

| Oleada | Añade | Composición |
|---|---|---|
| 1 | Errante | 4 errantes |
| 2 | Corredor | 2 errantes + 2 corredores |
| 3 | Resistente | 1 corredor + 2 resistentes + 1 errante |
| 4 | Bruto blindado | 2 resistentes + 1 bruto + 1 corredor |

### 5. Economía más dura

| Concepto | v0.9 | v1.0 | v1.1 |
|---|---|---|---|
| Recompensa por escape | 60 cr | 35 cr | **35 cr** |
| Bonus de suministros | +20 cr | +15 cr | **+15 cr** |
| Revólver R-6 | 150 cr | 320 cr | **320 cr** |
| Skin Renacida | 110 cr | 420 cr | **680 cr** |

### 6. Armas y munición por arma

| Arma | Precio | Cargador | Daño | Cadencia | Reserva inicial | Munición (precio · cantidad · tope) |
|---|---|---|---|---|---|---|
| Pistola 9 mm | 0 | 12 | 45 | 0,29 s | 18 | 14 cr · 12 · 3 cajas |
| Revólver R-6 | 320 | 6 | 90 | 0,60 s | 0 | 22 cr · 12 · 3 cajas |
| Vípera MP-9 | 480 | 24 | 28 | 0,11 s | 0 | 26 cr · 36 · 3 cargadores |
| Quiebra-12 | 620 | 5 | 26 ×6 perdigones | 0,78 s | 0 | 30 cr · 15 · 3 cajas |
| Cerraja-7 | 780 | 8 | 120 | 0,85 s | 0 | 34 cr · 16 · 3 peines |
| **Recortada C-2** | **700** | **2** | **34 ×8 perdigones** | **0,55 s** | 0 | **26 cr · 12 · 3 cajas** |
| **Carabina V-9** | **900** | **20** | **52** | **0,16 s** | 0 | **30 cr · 30 · 3 peines** |
| **Tiradora Larga** | **1150** | **5** | **165** | **1,05 s** | 0 | **40 cr · 10 · 3 cajas** |

La munición se compra **por arma**, con su propio tope y su propio stock persistente.
Lo comprado se consume al empezar la salida (`beginRun`), no se acumula como banco.

### 6b. Acoples (`attachments-rules.js`)

Una ranura por tipo: **bocacha, mira, cargador, culata**. Se compran una vez, se
montan y se quitan sin coste, y se guardan **por arma**.

| Acople | Ranura | Precio | Efecto | Tensión |
|---|---|---|---|---|
| Silenciador | Bocacha | 260 | Ruido −66%, atracción −55% | Daño −12% |
| Cañón pesado | Bocacha | 340 | Daño +18% | Movilidad −8%, retroceso +12% |
| Óptica 2× | Mira | 300 | Zoom +6°, dispersión −45%, alcance +20% | — |
| Cargador extendido | Cargador | 220 | Cargador +50% | Recarga +12% más lenta |
| Culata de apoyo | Culata | 240 | Retroceso −40%, dispersión −30% | — |

Compatibilidad: el silenciador no entra en escopetas ni en la Tiradora; el cargador
extendido no entra en revólver ni en escopetas; la culata no entra en pistola ni
revólver. La tienda muestra solo los acoples del arma equipada y marca los
incompatibles como `INCOMPATIBLE` en vez de ocultarlos.

### 7. Skins con tensión

| Skin | Precio | Modificadores |
|---|---|---|
| Superviviente | 0 | — (referencia) |
| Guardia carmesí | 320 | +20 vitales, −4% velocidad |
| Exploradora | 420 | +9% velocidad, −10 vitales |
| Chatarrera | 520 | +12% daño, −6% velocidad |
| Renacida | 680 | **+15% velocidad, −25 vitales** |

Las armas también pesan: `moveScale` va de 1,00 (pistola) a 0,78 (Tiradora Larga), así que
la elección nunca es obvia.

### 8. Persistencia real

`localStorage` bajo `distrito09.profile.v3`, con migración desde `v2` (sin acoples) y
`v1` (el contador `ammoPacks` se convierte en balas de pistola). Guarda créditos,
armas, munición por arma, skins, **acoples comprados y montados por arma**, arma y
skin equipadas, y el historial de salidas. Verificado cerrando y reabriendo: recarga
de página **y** contexto de navegador nuevo.

### 9. Editor de joystick en el primer arranque

En táctil, si el perfil no tiene ninguna salida completada, el editor se abre solo
sobre la intro ("coloca tus controles"). En escritorio no aparece: no hay joystick
que colocar.

### 10. Bifurcación de ruta

| Ruta | Peligro | Enemigos | Suministros |
|---|---|---|---|
| Corta (avenida directa) | ALTA | +6 infectados | ninguno |
| Larga (desvío por la clínica) | MEDIA | base | +15 cr al escapar, +6 balas y +15 vitales en el alijo |

Se elige una sola vez, en la bifurcación (z ≈ 8), y no hay vuelta atrás.

### Verificación

```bash
python3 -m http.server 8099 &
python3 tests/verify.py     # 58/58
```

Cubre: arranque sin errores de consola ni peticiones fallidas, 36 enemigos, caminar,
apuntar (FOV 58→44), disparo con impacto real, feedback visual, compra de arma +
munición + skin + acople por la UI, montaje y desmontaje del acople con su efecto
resuelto, los **tres desenlaces de caída** forzados uno a uno, persistencia tras
recarga, bifurcación de ruta, tensión de skin, escalado de oleadas, y una segunda
sesión móvil con sombras blob y shadow map apagado.

> Nota: con GL por software el reloj avanza ~45× más lento que en tiempo real, así
> que el arnés usa `?debug=1` (`__debugAdvance`, `__debugTeleport`,
> `__debugForceFall`, `__debugLandAll`) para mover la simulación de forma
> determinista. Esos hooks no existen sin el parámetro.

## v1.1 — qué cambió sobre v1.0

### 1. Zombis que caen de los edificios (`falling-zombies.js`)

Nueve repisas (azoteas y ventanas) repartidas por la avenida, entre z 34 y z −70.
El director elige una cuando el jugador está a 9–26 m, con 11 s de enfriamiento y
como máximo 3 en el aire. La caída es física simple: `y` sigue una cuadrática desde
la altura de la repisa, con giro en `z` y vuelco en `x`, y polvo al impactar.

| Desenlace | Prob. | Qué pasa |
|---|---|---|
| Muere con el impacto | 34% | Queda como cadáver tumbado en el suelo (26 s antes de reciclarse) |
| Se levanta furioso | 41% | Velocidad ×1,55 y daño ×1,6 durante 7 s, grito y aura roja pulsante |
| Queda arrastrándose | 25% | Acostado, velocidad ×0,34, daño ×0,7, animación de arrastre con los brazos |

El impacto y el grito usan el motor de audio existente con paneo estéreo según la
posición de la repisa respecto a la cámara.

### 2. Tres armas más

Recortada C-2 (700 cr), Carabina V-9 (900 cr) y Tiradora Larga (1150 cr), cada una
con su munición propia y su tope. Ver la tabla de la sección 6.

### 3. Acoples

Cinco acoples en cuatro ranuras, comprables, equipables y guardados por arma. Ver
la sección 6b.

### 4. Pantalla de inicio

La imagen de referencia es el fondo de la intro (`assets/branding/intro-bg.jpg`),
con un degradado direccional que mantiene el título y el botón legibles. En
escritorio la imagen ocupa la derecha y el texto va sobre el degradado; en vertical
la imagen sube y el bloque de texto baja. Verificado con capturas a 1280×720 y
390×844.

### 5. Persistencia ampliada

Perfil `v3`: añade acoples comprados y montados por arma, y las tres armas nuevas
con su munición. Migra desde `v2` y `v1` sin perder créditos ni armas.

### 6. Manifest de texto para el build

`build-apk.sh` leía `android/AndroidManifest.xml`, que no existía: el APK solo trae
el binario. Se añadió el manifest de texto con `versionCode 14` / `versionName 1.1`,
más `res/values/strings.xml` y `styles.xml` (tema sin barra de acción, fondo
`#0a1113`). El binario original sigue intacto como referencia.

## v1.2 — el APK ya se compila

Esta es la primera versión que **produce un APK firmado e instalable de verdad**.
`build-apk.sh` se ejecutó contra un SDK real (build-tools 35.0.0, platform
android-35, JDK 17) y el resultado está en `downloads/dead-strike-reborn-v1.2.apk`.

| | |
|---|---|
| Tamaño | 1.420.293 bytes |
| SHA-256 | `4e95583ccd169fb58747635f9b74a7d8c37074c6a699a0547fa3d4c267786177` |
| Firma | v2 + v3 verificadas con `apksigner verify` |
| Certificado | `CN=Distrito 09 Prototype`, RSA 2048, SHA-256 `03fb8977…` |
| Entradas | 43 (21 módulos JS + Three.js + branding + recursos + dex) |
| `resources.arsc` | ZIP_STORED (obligatorio para que instale) |

### Qué se arregló para que compilara

1. **Faltaba el manifest en texto.** El árbol solo traía el AXML binario extraído
   del APK. Se decodificó y se escribió `android/AndroidManifest.xml` con los
   valores reales (package, minSdk 26, targetSdk 35, cero permisos).
2. **`aapt` no acepta `platformBuildVersionCode`/`Name`** en el fuente: los inyecta
   él. Se quitaron.
3. **`javac` de JDK 17 rechaza `-bootclasspath` con `-target 17`.** `android.jar`
   pasa al classpath.
4. **Faltaba `mkdir -p "$WORK/gen"`** antes de `aapt package -J`.
5. **El script copiaba una lista fija de módulos** y se dejaba fuera cinco
   (`audio-engine`, `feedback`, `falling-zombies`, `joystick-editor`,
   `attachments-rules`). Ahora copia todos los `*.js` del árbol.
6. **El icono adaptativo estaba en binario.** Se reescribió el XML.
7. **El keystore se crea solo** si no existe (RSA 2048, 10.000 días).
8. **v1.2: las herramientas se invocan por ruta absoluta.** `aapt`, `d8` y
   `keytool` se llamaban por nombre y fallaban con `command not found` en cuanto
   el SDK no estaba en el `PATH`. Ahora usan `$BUILD_TOOLS/…` y `$JAVA_HOME/bin/…`.

### Verificación

`tests/verify.py` — **30 comprobaciones, todas en verde**:

```
PASS  no console errors on boot — 0: []
PASS  no failed requests on boot — 0: []
PASS  version is 1.2 — 1.2
PASS  depth fog is linear with a real near/far pair — {"type":"Fog","near":26,"far":96,"lamps":12,"pointLights":1,"blobDrawCalls":1,"blobCapacity":96}
PASS  blob shadows are one instanced field — drawCalls=1 capacity=96
PASS  street lighting is one recycled PointLight — pointLights=1 lamps=12
PASS  run starts with 36 enemies — 36
PASS  pistol starts 12/18 — 12/18
PASS  blob shadows cover player + 36 enemies — 37
PASS  shadow map stays off on touch — desktop context: full shadow map on
PASS  draw calls under 200 — calls=182
PASS  W walks forward (z decreases) — 54.00 -> 50.08
PASS  aiming narrows FOV — fov=44.0
PASS  shooting registers a shot — enemy
PASS  fall outcome "dead" resolves correctly — dead:true
PASS  fall outcome "enraged" resolves correctly — speed:3.18, damageMul:1.6, aura:true
PASS  fall outcome "crawler" resolves correctly — prone:true, speed:0.39
PASS  all three fall outcomes were counted — {"dead":1,"enraged":1,"crawler":1}
PASS  shop renders a card per weapon, skin, ammo line and attachment — 36 cards
PASS  new v1.2 weapon bought (Ráfaga B-3) — ['pistol','burst']
PASS  new weapon ammo bought with its own stock — rounds=30
PASS  attachment bought and owned — ['optic']
PASS  attachment mounted on the equipped weapon — {"burst":["optic"]}
PASS  mounted attachment changes the resolved stats — aimRange=50
PASS  profile survives a page reload — weapons=['pistol','burst'] ammo=30
PASS  mounted attachment survives the reload — {"burst":["optic"]}
PASS  a separate browser context has its own empty profile — credits=0 attachments=[]
PASS  no console errors in the fresh context — []
PASS  no console errors overall — 0: []
PASS  no failed requests overall — 0: []
30/30 checks passed
```

### v1.2 — armas, gráficos y animación

**Armas (12 en total).** Cuatro nuevas sobre v1.1: Ráfaga B-3 (1.350 cr, 30
balas, ráfaga de 3), Cazador .44 (1.750 cr, 6 balas, 210 daño), Corredera P-8
(1.950 cr, 8 cartuchos ×7 perdigones) y Mula-60 (2.400 cr, 60 balas, 0,085 s de
cadencia). Cada una con munición propia, precio y tope de reserva.

| Arma | Precio | Cargador | Daño | Cadencia | Munición |
|---|---|---|---|---|---|
| Pistola 9 mm | de serie | 12 | 45 | 0,29 s | 18 cr / 12 |
| Revólver R-6 | 420 | 6 | 90 | 0,60 s | 28 cr / 12 |
| Vípera MP-9 | 640 | 24 | 28 | 0,11 s | 32 cr / 36 |
| Quiebra-12 | 820 | 5 | 26×6 | 0,78 s | 38 cr / 15 |
| Recortada C-2 | 900 | 2 | 34×8 | 0,55 s | 32 cr / 12 |
| Cerraja-7 | 1.050 | 8 | 120 | 0,85 s | 44 cr / 16 |
| Carabina V-9 | 1.200 | 20 | 52 | 0,16 s | 36 cr / 30 |
| **Ráfaga B-3** | **1.350** | **30** | **34** | **0,42 s (×3)** | **40 cr / 30** |
| Tiradora Larga | 1.500 | 5 | 165 | 1,05 s | 52 cr / 10 |
| **Cazador .44** | **1.750** | **6** | **210** | **0,95 s** | **58 cr / 12** |
| **Corredera P-8** | **1.950** | **8** | **30×7** | **0,62 s** | **46 cr / 16** |
| **Mula-60** | **2.400** | **60** | **40** | **0,085 s** | **64 cr / 60** |

**Acoples (7, cuatro ranuras).** Silenciador (ruido −70%, daño +6%, atracción
−60%), Cañón pesado (daño +22%, movilidad −10%), Óptica 2× (zoom +7°,
dispersión −50%), Puntero láser (dispersión −38%), Cargador extendido (+50%),
Tambor de 60 (+110%, recarga +55%), Culata de apoyo (retroceso −45%).
Compatibilidad por arma, una pieza por ranura, guardado por arma.

**Gráficos.** Niebla lineal 26→96 m en vez de `FogExp2` a 0,0385 (que era opaca
a 40 m); un solo `PointLight` reciclado que salta a la farola más cercana en vez
de 8 luces estáticas; presets de rugosidad por familia de superficie (asfalto
0,62 / hormigón 0,93 / acero desnudo 0,28 / tela 0,95) en vez de 0,8 para todo;
blob shadows en **un** `InstancedMesh` con atributo de alfa por instancia.

**Draw calls: 349 → 182.** El recorte vino de agrupar la geometría estática de
la calle (458 cubos sueltos: edificios, farolas, barricadas, bordillos) en un
`InstancedMesh` por material, y de fijar una paleta de 6 fachadas en vez de
crear un material nuevo por edificio.

**Animación.** `zombie-animation.js` resuelve seis estados (caminar, correr,
caer, levantarse furioso, arrastrarse, morir) con un solver puro y testeable;
`weaponPose()` compone recarga y cambio de arma en primera persona. El feedback
de impacto (hitmarker, flash blanco, sacudida de 2–3 px, números de daño) ya
estaba desde v1.0 y sigue activo.

### Lo que sigue pendiente

1. **Instalar en hardware físico.** Todo lo verificado es Chromium con GL por
   software. Falta un Android real para medir las 37 blob shadows, el audio
   procedural y las caídas simultáneas en un dispositivo de gama media.
2. **Regenerar la clave de firma.** La actual es de prototipo y su huella está
   publicada en `docs/REAL_VS_RECONSTRUCTED.md`. Para distribuir, usa una propia.
3. **Pulido:** los 37 personajes siguen costando 9 mallas cada uno (~333 draw
   calls si todos están a la vista); instanciarlos por pieza es el siguiente
   recorte grande. Ampliar los asserts puros de `aim-rules` y `combat-rules`.

## Licencias

Three.js r160 bajo licencia MIT (`vendor/THREE-LICENSE.txt`). El resto del código es
del proyecto original. "Dead Strike Reborn" se declara **prototipo no oficial** en la
propia UI; el nombre "Dead Strike" pertenece a su autor original y este proyecto no
está afiliado a él.
