// RECONSTRUCTED FILE.
// The transcript only establishes that this is a Java-only WebView container
// (no Gradle, no Kotlin) that serves the game from
// https://appassets.androidplatform.net/assets/ through a custom WebViewClient
// and blocks every other request, with no INTERNET permission. The original
// source never appeared in the snapshot, so this is a faithful reimplementation
// of that contract rather than the original file.

package dev.distrito09.game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {

    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String ASSET_PREFIX = "/assets/";
    private static final String START_URL = "https://" + ASSET_HOST + ASSET_PREFIX + "index.html";

    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Landscape immersive: hide the status and navigation bars.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        web = new WebView(this);
        setContentView(web);
        hideSystemUi();

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // economy + joystick layout persistence
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setGeolocationEnabled(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Hardware acceleration for the WebGL canvas is on by default from
        // API 26 upward; the manifest flag documents the requirement.
        web.setBackgroundColor(0xFF080B0E);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new AssetClient());

        // The native shell requests the touch HUD explicitly.
        String url = START_URL + "?touch=1";
        if (Build.VERSION.SDK_INT >= 26) {
            web.loadUrl(url);
        } else {
            web.loadUrl(url);
        }
    }

    /** Immersive sticky mode; also hides the bars again after a swipe. */
    private void hideSystemUi() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    public void onBackPressed() {
        // The game owns Escape-like behaviour; a back press pauses rather than
        // closing the activity and losing the run.
        web.evaluateJavascript(
                "(function(){try{window.dispatchEvent(new KeyboardEvent('keydown',{code:'Escape'}));}catch(e){}})();",
                null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        hideSystemUi();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    /**
     * Serves bundled assets from the APK and refuses everything else.
     * Because the app holds no INTERNET permission, a real network request
     * could not succeed anyway; this makes the intent explicit.
     */
    private class AssetClient extends WebViewClient {

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            String host = request.getUrl().getHost();
            String path = request.getUrl().getPath();

            if (ASSET_HOST.equals(host) && path != null && path.startsWith(ASSET_PREFIX)) {
                String assetPath = path.substring(ASSET_PREFIX.length());
                try {
                    InputStream stream = getAssets().open(assetPath);
                    return new WebResourceResponse(mimeFor(assetPath), "utf-8", stream);
                } catch (IOException missing) {
                    return new WebResourceResponse("text/plain", "utf-8", null);
                }
            }

            // Anything that is not a bundled asset is blocked outright.
            return new WebResourceResponse("text/plain", "utf-8", null);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            String host = request.getUrl().getHost();
            return !ASSET_HOST.equals(host);
        }

        private String mimeFor(String assetPath) {
            if (assetPath.endsWith(".html")) return "text/html";
            if (assetPath.endsWith(".js") || assetPath.endsWith(".mjs")) return "text/javascript";
            if (assetPath.endsWith(".css")) return "text/css";
            if (assetPath.endsWith(".svg")) return "image/svg+xml";
            if (assetPath.endsWith(".png")) return "image/png";
            if (assetPath.endsWith(".jpg") || assetPath.endsWith(".jpeg")) return "image/jpeg";
            if (assetPath.endsWith(".json")) return "application/json";
            return "application/octet-stream";
        }
    }
}
