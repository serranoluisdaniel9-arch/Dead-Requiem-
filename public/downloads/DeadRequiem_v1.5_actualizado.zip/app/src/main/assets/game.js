import * as THREE from './vendor/three.module.js';
import { decorateStreet } from './street-detail.js';
import { MISSION, ROUTES, ENEMY_TYPES, createMission, missionTarget, nearbyInteraction, applyInteraction, createEnemySpawns, routePickups } from './mission-rules.js';
import { createMissionWorld } from './mission-world.js';
import { DEFAULT_CONTROLS, loadControls, normalizeControls, saveControls } from './controls-settings.js';
import { ECONOMY_KEY, LEGACY_ECONOMY_KEY, WEAPONS, SKINS, ATTACHMENTS, EXTRACTION_REWARD, SUPPLIES_BONUS, defaultProfile, normalizeProfile, loadProfile, saveProfile, purchase, equip, beginRun, rewardExtraction, runStats } from './economy-rules.js';
import { createAudioEngine } from './audio-engine.js';
import { createFeedback, createBlobTexture, createBlobShadow } from './feedback.js';
import { createShop } from './shop-ui.js';
import { applyLook, aimDirection, aimCandidates, rayBox } from './aim-rules.js';
import { COMBAT, reloadDuration, tapBypassesCooldown, chooseShoveTarget, shoveEffect } from './combat-rules.js';
import { loadJoystick, normalizeJoystick, joystickLayout } from './joystick-settings.js';
import { createJoystickEditor } from './joystick-editor.js';
import { createCharacterFactory } from './character-models.js';
import { WAVES, ESCALATION, createWaveState, advanceWaves, planWaveSpawns } from './wave-rules.js';

const $ = id => document.getElementById(id);
const canvas = $('game');
let renderer;
try {
  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: false,
    powerPreference: 'high-performance',
    precision: 'mediump'
  });
} catch (e) {
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'default' });
  } catch (e2) {
    $('loading').textContent = 'Error WebGL: ' + (e2.message || e2);
    throw e2;
  }
}
const touch = true;
document.documentElement.classList.add('touch-device');
const initialW = Math.max(320, window.innerWidth || document.documentElement.clientWidth || 800);
const initialH = Math.max(240, window.innerHeight || document.documentElement.clientHeight || 480);
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.35));
renderer.setSize(initialW, initialH, false);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene();
scene.background = new THREE.Color('#101822');
scene.fog = new THREE.FogExp2('#101822', .032);
// Fog is essentially opaque at this distance; don't draw the hidden far city.
const camera = new THREE.PerspectiveCamera(58, initialW / initialH, .06, 180);
const clock = new THREE.Clock();
const V = THREE.Vector3;
let seed = 9042;
function rand(a=0,b=1) { seed=(Math.imul(seed,1664525)+1013904223)>>>0;return a+(seed/4294967296)*(b-a); }
const clamp = THREE.MathUtils.clamp;
const mat = (color,extra={})=>new THREE.MeshStandardMaterial({color,roughness:.72,metalness:.2,...extra});
const M = {
  asphalt:mat('#1f262d',{roughness:.62}), pavement:mat('#353d42'), concrete:mat('#3a444b'),
  trim:mat('#11171c'), line:mat('#b5a56d'), steel:mat('#36464c',{metalness:.75,roughness:.32}),
  boots:mat('#171a19'),
  glow:mat('#ffba6d',{emissive:'#ff9232',emissiveIntensity:3.2}), cyan:mat('#7bdfdf',{emissive:'#409faa',emissiveIntensity:1.5})
};
const boxGeo = new THREE.BoxGeometry(1,1,1);
const obstacles=[];
function box(parent,w,h,d,x,y,z,material,shadow=true){
  const o=new THREE.Mesh(boxGeo,material);o.scale.set(w,h,d);o.position.set(x,y,z);
  o.castShadow=shadow;o.receiveShadow=true;parent.add(o);return o;
}
scene.add(new THREE.HemisphereLight('#87a0b8','#221d18',1.4));
const moon=new THREE.DirectionalLight('#c8dcff',1.8);moon.position.set(-18,32,-24);scene.add(moon);
moon.castShadow=true;moon.shadow.mapSize.set(2048,2048);moon.shadow.camera.left=-24;moon.shadow.camera.right=24;moon.shadow.camera.top=30;moon.shadow.camera.bottom=-30;moon.shadow.bias=-.0004;moon.shadow.normalBias=.02;
scene.add(moon.target);

// Every visual asset is generated here: no extracted game models or textures.
function asphaltTexture(){
  const c=document.createElement('canvas');c.width=c.height=256;const x=c.getContext('2d');
  x.fillStyle='#647079';x.fillRect(0,0,256,256);
  for(let n=0;n<11000;n++){const g=Math.floor(rand(45,115));x.fillStyle=`rgba(${g},${g},${g},.28)`;x.fillRect(rand(0,256),rand(0,256),rand(1,3),1);}
  const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(8,50);t.colorSpace=THREE.SRGBColorSpace;return t;
}
M.asphalt.map=asphaltTexture();
box(scene,160,.6,230,0,-.5,-10,mat('#263239'));
box(scene,19,.15,190,0,-.12,-10,M.asphalt);
for(const side of [-1,1]){
  box(scene,3,.24,190,side*10.4,-.03,-10,M.pavement);
  box(scene,.2,.28,190,side*8.95,.02,-10,mat('#858b83'));
  for(let i=0;i<24;i++)box(scene,2.9,.012,.035,side*10.4,.101,-98+i*8,mat('#59636a'),false);
}
const stripe = new THREE.InstancedMesh(boxGeo,M.line,40);
const dummy=new THREE.Object3D();
for(let i=0;i<40;i++){dummy.position.set(0,-.027,-102+i*5);dummy.scale.set(.13,.015,2.1);dummy.updateMatrix();stripe.setMatrixAt(i,dummy.matrix);}scene.add(stripe);
// A crosswalk at the starting intersection.
for(let i=-4;i<=4;i++)box(scene,1.1,.014,2.8,i*1.85,-.02,20,mat('#9b9f93'),false);
const windowMats=[mat('#8daba4',{emissive:'#518d87',emissiveIntensity:.12}),mat('#a99c7a',{emissive:'#b3945a',emissiveIntensity:.1}),mat('#3b4645')];
const windows=[[],[],[]];
for(const side of [-1,1])for(let i=0;i<15;i++){
  const z=-105+i*13, h=rand(10,29),w=rand(7,12),d=rand(10.7,12.5),x=side*(12+w/2);
  const bm=mat(new THREE.Color().setHSL(rand(.10,.17),rand(.025,.07),rand(.40,.58)));
  box(scene,w,h,d,x,h/2,z,bm);
  box(scene,w+.3,.38,d+.25,x,h,z,M.trim);
  box(scene,.35,h,.5,side*12.1,h/2,z-d/2+.2,M.concrete);
  box(scene,.25,3,d-1,side*11.91,1.55,z,M.trim);
  for(let floor=0;floor<Math.floor((h-3)/3);floor++)for(let col=0;col<4;col++){
    const wz=z-d*.35+col*d*.235,wy=4.5+floor*3;
    const k=rand()<.32?Math.floor(rand(0,2)):2;windows[k].push([side*11.88,wy,wz]);
  }
  // Roof equipment and street-facing doorway.
  box(scene,2.1,1.3,2.5,x,h+.65,z,M.steel);
  box(scene,.1,2.6,1.8,side*11.75,1.35,z,M.steel);
}
windows.forEach((positions,k)=>{const mesh=new THREE.InstancedMesh(boxGeo,windowMats[k],positions.length);positions.forEach((p,i)=>{dummy.position.set(...p);dummy.scale.set(.08,1.45,1.4);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});scene.add(mesh);});

function sign(text,sub,color,x,z,side){
  const c=document.createElement('canvas');c.width=768;c.height=256;const ctx=c.getContext('2d');
  ctx.fillStyle='#142026';ctx.fillRect(0,0,768,256);ctx.strokeStyle=color;ctx.lineWidth=8;ctx.strokeRect(12,12,744,232);
  ctx.textAlign='center';ctx.fillStyle=color;ctx.font='bold 85px sans-serif';ctx.fillText(text,384,128);
  ctx.fillStyle='#c1c9c4';ctx.font='28px monospace';ctx.fillText(sub,384,190);
  const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
  const m=new THREE.MeshBasicMaterial({map:tex});const mesh=new THREE.Mesh(new THREE.PlaneGeometry(4.6,1.53),m);
  mesh.position.set(x,4,z);mesh.rotation.y=side<0?Math.PI/2:-Math.PI/2;scene.add(mesh);
}

sign('REFUGIO','NO QUEDAN PLAZAS','#e9b06d',11.7,-30,1);
sign('ÚLTIMA LUZ','SUMINISTROS · 24H','#d5b982',-11.7,37,-1);
for(let i=0;i<12;i++){
  const side=i%2?1:-1,z=-88+i*15,x=side*8.35;
  box(scene,.13,6.2,.13,x,3.1,z,M.steel);
  box(scene,1.25,.12,.14,x-side*.6,6.13,z,M.steel);
  box(scene,.6,.08,.32,x-side*1.15,6.04,z,M.glow,false);
  if(i%3===0){const light=new THREE.PointLight('#ffce9b',5,12,2);light.position.set(x-side*1.1,5.8,z);scene.add(light);}
  box(scene,.32,.38,.32,x,.18,z,M.steel);
  // Soft, inexpensive pools of light on the wet pavement.

}
function car(x,z,color,angle=0){
  const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=angle;scene.add(g);
  const body=mat(color,{metalness:.48,roughness:.36});
  box(g,1.85,.65,3.7,0,.7,0,body);box(g,1.55,.7,1.9,0,1.3,-.2,body);
  box(g,1.57,.48,.04,0,1.4,.77,mat('#233c43',{metalness:.8,roughness:.15}));
  box(g,1.57,.48,.04,0,1.4,-1.17,M.trim);
  for(const sx of [-1,1])for(const sz of [-1,1]){
    const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.37,.37,.2,10),M.boots);wheel.rotation.z=Math.PI/2;wheel.position.set(sx*.94,.39,sz*1.15);g.add(wheel);
  }
  box(g,1.5,.15,.08,0,.55,1.9,M.steel);
  for(const sx of [-1,1]){box(g,.38,.17,.07,sx*.58,.79,1.89,mat('#d8d7ac',{emissive:'#b3a777',emissiveIntensity:.35}));box(g,.3,.16,.07,sx*.65,.84,-1.89,mat('#8c3330',{emissive:'#69241a',emissiveIntensity:.3}));}
  obstacles.push({x,z,rx:1.2,rz:2.25});
}
car(-6,5,'#586d70',.12);car(6,-18,'#746c51',-.1);car(-6,-43,'#5c6664',.05);car(6,44,'#554345',-.08);
// Scattered barricades and waste containers on the sidewalk.
for(let i=0;i<13;i++){
  const side=i%2?1:-1,z=-85+i*13;
  box(scene,.85,1.15,.85,side*10.5,.6,z,mat('#344a47'));
  box(scene,.95,.12,.95,side*10.5,1.2,z,M.trim);
  obstacles.push({x:side*10.5,z,rx:.48,rz:.48});
}
decorateStreet({THREE,scene,materials:M,obstacles});
const missionWorld=createMissionWorld({THREE,scene,materials:M,mission:MISSION});
// Volumetric impression through drifting translucent road mist.
function radialTexture(){const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d');const g=ctx.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(255,255,255,.8)');g.addColorStop(.3,'rgba(255,255,255,.28)');g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(0,0,64,64);return new THREE.CanvasTexture(c);}
const glowTexture=radialTexture();
const mist=[];
for(let i=0;i<12;i++){const s=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTexture,color:'#cbd0c7',transparent:true,opacity:.10,depthWrite:false}));s.position.set(rand(-8,8),rand(.2,1.5),rand(-80,70));s.scale.set(rand(9,17),rand(2,4),1);scene.add(s);mist.push(s);}
const rainCount=240;const rainPositions=new Float32Array(rainCount*6);
for(let i=0;i<rainCount;i++){const j=i*6,x=rand(-18,18),y=rand(0,20),z=rand(-35,35);rainPositions.set([x,y,z,x-.12,y-.65,z],j);}
const rainGeo=new THREE.BufferGeometry();rainGeo.setAttribute('position',new THREE.BufferAttribute(rainPositions,3));
const rain=new THREE.LineSegments(rainGeo,new THREE.LineBasicMaterial({color:'#a0bdc8',transparent:true,opacity:.22,depthWrite:false}));rain.visible=false;scene.add(rain);

// Snapshot solid scenery before adding characters or weapon/effect models.
const shotBlockers=[];
scene.traverse(object=>{
  if(object.isMesh&&!Array.isArray(object.material)&&!object.material.transparent)shotBlockers.push(object);
});

const characterVisuals=createCharacterFactory({THREE});
// Blob shadows: a soft radial plane under every character. They are the only
// grounding cue on touch devices, where the shadow map is deliberately off.
const blobTexture=createBlobTexture(THREE);
function groundCharacter(character){
  if(character.shadow)character.shadow.position.y=(Math.abs(character.group.position.x)>9?.095:-.04)-character.group.position.y;
}
const feedback=createFeedback({container:$('app'),crosshair:$('crosshair')});
function human(zombie=false,variant=0,kind='shambler'){
  const body=characterVisuals.createBody(zombie,variant,kind);
  const {group,upper}=body;
  const shadow=createBlobShadow(THREE,blobTexture,{width:zombie?.86:.8,depth:zombie?.6:.56,opacity:zombie?.46:.42});
  shadow.rotation.x=-Math.PI/2;shadow.position.y=-.04;group.add(shadow);body.details.push(shadow);body.shadow=shadow;
  let gun,muzzle,gunModels,gunRig;
  if(!zombie){
    gunRig=new THREE.Group();gunRig.position.set(-.40,1.49-upper.position.y,0);upper.add(gunRig);
    gun=new THREE.Group();gun.position.set(0,0,.57);gunRig.add(gun);
    const pistol=new THREE.Group(),revolver=new THREE.Group(),smg=new THREE.Group(),shotgun=new THREE.Group(),rifle=new THREE.Group(),assault=new THREE.Group(),sniper=new THREE.Group(),flamethrower=new THREE.Group();
    gun.add(pistol,revolver,smg,shotgun,rifle,assault,sniper,flamethrower);
    gunModels={pistol,revolver,smg,shotgun,rifle,assault,sniper,flamethrower};
    box(pistol,.105,.125,.33,0,0,.13,M.steel);box(pistol,.09,.19,.115,0,-.11,.015,M.trim);box(pistol,.055,.055,.13,0,.0,.35,M.trim);box(pistol,.018,.025,.035,0,.08,.285,M.trim);
    box(revolver,.11,.15,.21,0,-.015,.1,M.steel);box(revolver,.105,.2,.12,0,-.12,-.015,M.trim);
    const drum=new THREE.Mesh(new THREE.CylinderGeometry(.082,.082,.18,8),M.steel);drum.rotation.x=Math.PI/2;drum.position.set(0,.02,.14);revolver.add(drum);
    const barrel=new THREE.Mesh(new THREE.CylinderGeometry(.035,.035,.32,8),M.steel);barrel.rotation.x=Math.PI/2;barrel.position.set(0,.035,.39);revolver.add(barrel);
    box(revolver,.025,.025,.035,0,.085,.51,M.trim);box(revolver,.04,.065,.025,0,.055,-.02,M.steel);
    // SMG: compact receiver, long magazine, folded stock.
    box(smg,.1,.13,.42,0,0,.16,M.steel);box(smg,.075,.2,.1,0,-.13,.06,M.trim);
    box(smg,.05,.05,.2,0,.005,.42,M.trim);box(smg,.06,.16,.07,0,-.1,.2,M.trim);
    box(smg,.03,.05,.16,0,.02,-.12,M.trim);
    // Shotgun: wide twin barrels and a wooden stock.
    box(shotgun,.13,.11,.5,0,.01,.2,M.steel);box(shotgun,.1,.1,.16,0,-.02,-.16,mat('#6b5334'));
    box(shotgun,.05,.05,.44,0,.075,.24,M.trim);box(shotgun,.11,.06,.1,0,-.06,.1,mat('#6b5334'));
    // Rifle: long barrel, scope, straight stock.
    box(rifle,.09,.11,.62,0,0,.26,M.steel);box(rifle,.08,.13,.2,0,-.02,-.2,mat('#4a4a3c'));
    box(rifle,.04,.04,.5,0,.02,.62,M.trim);
    const scope=new THREE.Mesh(new THREE.CylinderGeometry(.035,.035,.22,8),M.trim);scope.rotation.x=Math.PI/2;scope.position.set(0,.1,.24);rifle.add(scope);
    box(rifle,.05,.1,.08,0,-.1,.12,M.trim);
    // Assault Rifle (Furia M4): tactical composite receiver, curved banana mag, barrel handguard, top rail
    box(assault,.095,.14,.54,0,0,.18,M.steel);box(assault,.08,.12,.18,0,-.02,-.16,mat('#242e39'));
    box(assault,.05,.05,.36,0,.02,.54,M.trim);box(assault,.065,.19,.12,0,-.14,.17,mat('#151b22'));
    box(assault,.04,.07,.2,0,.095,.16,M.trim);box(assault,.08,.11,.24,0,.01,.36,mat('#3d4b56'));
    // Sniper Rifle (Ojo de Halcón): ultra-long precision barrel, high-power telescopic scope, bipod mount
    box(sniper,.09,.12,.76,0,0,.24,M.steel);box(sniper,.085,.14,.24,0,-.03,-.22,mat('#362a24'));
    box(sniper,.042,.042,.64,0,.02,.78,M.trim);box(sniper,.068,.068,.10,0,.02,1.10,M.steel);
    const sniperScope=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,.36,12),M.trim);
    sniperScope.rotation.x=Math.PI/2;sniperScope.position.set(0,.11,.26);sniper.add(sniperScope);
    box(sniper,.035,.07,.05,0,.06,.15,M.steel);box(sniper,.035,.07,.05,0,.06,.37,M.steel);
    box(sniper,.06,.12,.10,0,-.11,.14,M.trim);
    // Flamethrower (Infierno Napalm): dual pressurized tanks, heavy combustion valve, flame nozzle
    const tank1=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.42,10),mat('#b91c1c',{roughness:.4,metalness:.6}));
    tank1.rotation.x=Math.PI/2;tank1.position.set(-.06,-.05,.12);flamethrower.add(tank1);
    const tank2=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.42,10),mat('#c2410c',{roughness:.4,metalness:.6}));
    tank2.rotation.x=Math.PI/2;tank2.position.set(.06,-.05,.12);flamethrower.add(tank2);
    box(flamethrower,.14,.12,.48,0,.03,.22,M.steel);
    const flameNozzle=new THREE.Mesh(new THREE.CylinderGeometry(.055,.08,.36,12),M.trim);
    flameNozzle.rotation.x=Math.PI/2;flameNozzle.position.set(0,.04,.52);flamethrower.add(flameNozzle);
    box(flamethrower,.03,.03,.08,0,.11,.66,mat('#f59e0b',{emissive:'#d97706',emissiveIntensity:1.5}));

    for(const model of [revolver,smg,shotgun,rifle,assault,sniper,flamethrower])model.visible=false;
    muzzle=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTexture,color:'#ffd797',transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));muzzle.position.set(0,.01,.43);muzzle.scale.set(.65,.65,1);muzzle.visible=false;
    const muzzleLight=new THREE.PointLight('#ffaa44',0,12,2);muzzleLight.name='muzzleLight';muzzle.add(muzzleLight);
    gun.add(muzzle);
  }
  return {...body,gun,muzzle,gunModels,gunRig};
}
const player=human();scene.add(player.group);player.group.position.set(MISSION.start.x,0,MISSION.start.z);player.group.rotation.y=Math.PI;
const torch=new THREE.SpotLight('#f0e0b4',0,28,.49,.65,1.4);torch.position.set(0,1.6,11);scene.add(torch);scene.add(torch.target);
let enemies=[],effects=[];
let phase='intro',health=100,ammo=MISSION.initialAmmo,reserve=MISSION.initialReserve,kills=0;
let profile=loadProfile(),profilePersistent=saveProfile(profile),activeWeapon=WEAPONS.pistol,activeSkin='survivor';
let runMaxHealth=100,runSpeedScale=1,runDamageScale=1;
let currentRunId=null,lastRunAward=0,shopReturnPhase='intro',shopReturnFocus=null;
let missionProgress=createMission(),interaction=null,noiseCount=0,invulnerable=0;
let lastStage='',lastDistance=-1,lastThreat='',growlTime=4,stepTime=0;
let yaw=0,pitch=0,shotCooldown=0,reloadTime=0,reloadBlend=0,gameTime=0,walkTime=0,damageFade=0,recoil=0,muzzleTime=0;
let lastShot=null;
let reloadTotal=0,reloadMode=null,shoveCooldown=0,shoveTime=0,lastShove=null,firePointerId=null;
let fireHeld=false,stickX=0,stickY=0,lastHealth=-1,lastAmmo=-1,lastKills=-1;
let aiming=false,aimBlend=0;
let controlSettings=loadControls();
let joystickSettings=loadJoystick();
let waveProgress=createWaveState(),waveSpawned=0;
let appliedWaves=new Set(),lastWaveSpawns=[],lastWaveOrigin=null;
const maxReinforcements=WAVES.reduce((sum,wave)=>sum+wave.members.length,0);
let statusTime=0,statusText='';
const keys=new Set();
let soundOn=true;
const audioEngine=createAudioEngine();
function initAudio(){audioEngine.resume();}
// Legacy call sites keep their names; the engine owns the synthesis.
function sound(type,pan=0,extra){ 
  if(!soundOn)return;
  if(type==='shot')audioEngine.shot(extra||activeWeapon.id,pan);
  else if(type==='hit')audioEngine.impact(pan,true);
  else if(type==='world')audioEngine.impact(pan,false);
  else if(type==='reload')audioEngine.reload(pan);
  else if(type==='growl')audioEngine.growl(pan,extra||10);
  else if(type==='step')audioEngine.step(pan,extra||1);
  else if(type==='hurt')audioEngine.hurt(pan);
  else if(type==='pickup')audioEngine.pickup(pan);
  else audioEngine.ui(type);
}
/** Stereo position of a world point relative to where the camera is looking. */
function panFor(position){
  const p=player.group.position;
  const dx=position.x-p.x,dz=position.z-p.z;
  const rightX=Math.cos(yaw),rightZ=Math.sin(yaw);
  const distance=Math.hypot(dx,dz)||1;
  return clamp((dx*rightX+dz*rightZ)/distance,-1,1);
}
function toast(text,duration=2.5){statusText=text;statusTime=duration;$('status').textContent=text;$('status').classList.add('visible');}
function spawnEnemy(spawn,i,incoming=false){
    if(enemies.some(e=>e.id===spawn.id))return null;
    if(incoming&&collides(spawn.x,spawn.z,.38))return null;
    const e=human(true,spawn.kind==='brute'?5:spawn.kind==='resistant'?4:i%4,spawn.kind);
    let x=spawn.x,z=spawn.z;
    if(collides(x,z,.35)){
      for(const offset of [-1.7,1.7,-3.4,3.4,5,-5]){
        if(!collides(x+offset,z,.35)&&Math.abs(x+offset)<8){x+=offset;break;}
      }
      if(collides(x,z,.35))x=0;
    }
    e.id=spawn.id;e.kind=spawn.kind;e.hp=e.maxHp=spawn.hp;e.speed=spawn.speed;
    e.group.position.set(x,0,z);e.group.rotation.y=spawn.yaw;
    if(e.kind==='brute')e.group.scale.set(1.18,1.12,1.18);
    else if(e.kind==='resistant')e.group.scale.set(1.07,1.02,1.07);
    e.home=new V(x,0,z);e.lastKnown=e.home.clone();e.wander=e.home.clone();
    e.attack=.5;e.anim=i*1.7;e.dead=false;e.fade=0;e.alert=0;e.mode='idle';e.wanderTimer=2+i%6;e.stagger=0;
    e.reinforcement=incoming;
    scene.add(e.group);enemies.push(e);
    return e;
}
const WINDOW_DROPS=[
  {zTrigger:12,side:-1,windowZ:7,spawned:false},
  {zTrigger:-15,side:1,windowZ:-20,spawned:false},
  {zTrigger:-48,side:-1,windowZ:-52,spawned:false},
  {zTrigger:-72,side:1,windowZ:-76,spawned:false}
];
let fallingZombies=[];
function resetWindowDrops(){
  WINDOW_DROPS.forEach(d=>d.spawned=false);
  fallingZombies=[];
}
function checkWindowDrops(){
  if(phase!=='playing')return;
  const pz=player.group.position.z;
  for(const drop of WINDOW_DROPS){
    if(!drop.spawned && pz<=drop.zTrigger){
      drop.spawned=true;
      spawnFallingZombie(drop.side, drop.windowZ);
    }
  }
}
function spawnFallingZombie(side, z){
  const e=human(true,2,'runner');
  const x=side*9.8;
  e.id=`window-drop-${z}`;
  e.kind='runner';
  e.hp=e.maxHp=45;
  e.speed=2.25;
  e.group.position.set(x,6.5,z);
  e.group.rotation.y=side<0?Math.PI/2:-Math.PI/2;
  e.home=new V(x,0,z);
  e.lastKnown=player.group.position.clone();
  e.wander=e.home.clone();
  e.attack=.4;e.anim=0;e.dead=false;e.fade=0;e.alert=15;e.mode='chase';e.wanderTimer=3;e.stagger=1.6;
  e.reinforcement=true;
  scene.add(e.group);
  enemies.push(e);
  fallingZombies.push({enemy:e, vy:0, grounded:false});
  toast('¡Un infectado cayó desde la ventana!',2.5);
  sound('growl',panFor(e.group.position),12);
}
function populateDistrict(){
  const spawns=createEnemySpawns(missionProgress.route);
  spawns.forEach((spawn,i)=>spawnEnemy(spawn,i));
  if(currentEnv==='night'||currentEnv==='night_rain'){
    const extra=[
      {id:'night-1',kind:'runner',x:-2,z:15,yaw:0,hp:35,speed:2.1},
      {id:'night-2',kind:'shambler',x:4,z:-5,yaw:Math.PI,hp:45,speed:1.2},
      {id:'night-3',kind:'runner',x:-3,z:-32,yaw:.5,hp:35,speed:2.1},
      {id:'night-4',kind:'resistant',x:2,z:-60,yaw:-.8,hp:80,speed:1.05},
      {id:'night-5',kind:'runner',x:-1,z:-82,yaw:Math.PI,hp:38,speed:2.2}
    ];
    extra.forEach((s,idx)=>spawnEnemy(s,spawns.length+idx,true));
  }
  resetWindowDrops();
}
function spawnWave(wave){
  if(phase!=='playing'||missionProgress.stage==='complete'||appliedWaves.has(wave.id))return;
  appliedWaves.add(wave.id);
  const p=player.group.position;
  const occupied=enemies.filter(e=>!e.dead).map(e=>({x:e.group.position.x,z:e.group.position.z}));
  const planned=planWaveSpawns(wave,{x:p.x,z:p.z},{occupied,blocked:(x,z)=>collides(x,z,.38)});
  const records=[];
  for(const descriptor of planned){
    if(waveSpawned>=maxReinforcements)break;
    const kind=descriptor.kind;
    const speed=kind==='runner'?2.05:kind==='brute'?.82:kind==='resistant'?1.02:1.2;
    const enemy=spawnEnemy({...descriptor,hp:ENEMY_TYPES[kind].hp,speed},enemies.length,true);
    if(!enemy)continue;
    enemy.lastKnown.copy(p);enemy.alert=12;enemy.mode='investigate';
    waveSpawned++;
    records.push({id:enemy.id,kind,x:enemy.group.position.x,z:enemy.group.position.z});
  }
  lastWaveSpawns=records;lastWaveOrigin={x:p.x,z:p.z};
  const number=WAVES.findIndex(w=>w.id===wave.id)+1;
  const ladder=ESCALATION.find(step=>step.wave===number);
  toast(records.length?`Oleada ${number}/${WAVES.length} · ${ladder?ladder.adds:'refuerzos'}: llegan ${records.length} infectados.`:'Los infectados no encontraron una entrada segura.',3);
}
function updateWaves(){
  const result=advanceWaves(waveProgress,{z:player.group.position.z,time:gameTime,active:phase==='playing',complete:missionProgress.stage==='complete'});
  waveProgress=result.state;
  if(result.arriving)spawnWave(result.arriving);
  if(result.announced){
    const number=WAVES.findIndex(w=>w.id===result.announced.id)+1;
    const ladder=ESCALATION.find(step=>step.wave===number);
    toast(`Se acerca la oleada ${number}/${WAVES.length}${ladder?` · ${ladder.adds}`:''}. Busca una ruta libre.`,result.announced.delay);
    sound('growl',0,14);
  }
}
function makeNoise(radius=30){
  noiseCount++;
  const p=player.group.position;
  for(const e of enemies){if(!e.dead&&e.group.position.distanceTo(p)<radius){e.lastKnown.copy(p);e.alert=10;e.mode='investigate';}}
}
function interact(){
  if(phase!=='playing')return;
  const item=nearbyInteraction(player.group.position,missionProgress);
  if(!item)return;
  if(item.kind==='health'&&health>=runMaxHealth){toast('Ya tienes la salud completa. Puedes dejar el botiquín.',2);return;}
  if(item.kind==='fork'){openRouteChoice();return;}
  const result=applyInteraction(missionProgress,item.id);
  if(!result.event)return;
  missionProgress=result.progress;
  reserve+=result.reward.ammo||0;health=Math.min(runMaxHealth,health+(result.reward.health||0));
  sound('pickup');
  if(result.event==='supplies'){
    makeNoise(28);toast(`Alijo de suministros: +${SUPPLIES_BONUS} créditos si escapas.`,4);
  }else if(result.event==='extract'){endGame(true);}
  else if(result.event==='ammo'){toast(`+${result.reward.ammo} balas. Cada disparo cuenta.`,3);}
  else if(result.event==='health'){toast(`+${result.reward.health} salud`,2);}
  updateHUD(true);
}
/** The fork: two routes, chosen once, with their trade-off spelled out. */
function openRouteChoice(){
  if(phase!=='playing'||missionProgress.stage!=='route')return;
  phase='route';
  resetInputs();
  $('route').classList.remove('hidden');
  $('route-short').focus({preventScroll:true});
}
function chooseRoute(id){
  if(phase!=='route')return;
  const result=applyInteraction(missionProgress,`fork`,id);
  if(!result.event)return;
  missionProgress=result.progress;
  $('route').classList.add('hidden');
  phase='playing';
  const route=ROUTES[id]||ROUTES.short;
  // The short route is the dangerous one: its extra infected arrive now.
  if(route.extraEnemies>0){
    const base=enemies.length;
    createEnemySpawns(id).slice(36).forEach((spawn,i)=>spawnEnemy(spawn,base+i));
  }
  toast(`${route.name}: ${route.description}`,4);
  sound('ui');
  updateHUD(true);
}
function lineBlocked(a,b){
  const dx=b.x-a.x,dz=b.z-a.z;
  for(const o of obstacles){
    let near=0,far=1;
    for(const [start,delta,mid,half]of [[a.x,dx,o.x,o.rx],[a.z,dz,o.z,o.rz]]){
      if(Math.abs(delta)<.0001){if(Math.abs(start-mid)>half){near=2;break;}}
      else{let t1=(mid-half-start)/delta,t2=(mid+half-start)/delta;if(t1>t2)[t1,t2]=[t2,t1];near=Math.max(near,t1);far=Math.min(far,t2);}
    }
    if(near<=far&&far>.03&&near<.97)return true;
  }
  return false;
}
function start(){
  if(!['intro','end'].includes(phase))return;
  refreshProfile();
  const prepared=beginRun(profile,newRunId());
  currentRunId=prepared.runId;lastRunAward=0;
  commitProfile(prepared.profile);
  applyLoadout(prepared.loadout.weapon,prepared.loadout.skin);
  runMaxHealth=prepared.loadout.maxHealth;runSpeedScale=prepared.loadout.speedScale;runDamageScale=prepared.loadout.damageScale;
  const totalAmmo=prepared.loadout.magazine+prepared.loadout.reserve;
  initAudio();audioEngine.startAmbience();
  enemies.forEach(e=>scene.remove(e.group));effects.forEach(e=>{scene.remove(e.object);if(e.type==='line')e.object.geometry.dispose();e.object.material.dispose();});enemies=[];effects=[];
  feedback.clear();
  health=runMaxHealth;ammo=Math.min(activeWeapon.magazine,totalAmmo);reserve=totalAmmo-ammo;kills=0;reloadTime=reloadBlend=0;shotCooldown=0;gameTime=0;yaw=pitch=0;recoil=0;lastShot=null;stepTime=0;
  reloadTotal=shoveCooldown=shoveTime=0;reloadMode=null;lastShove=null;
  waveProgress=createWaveState();waveSpawned=0;appliedWaves=new Set();lastWaveSpawns=[];lastWaveOrigin=null;
  missionProgress=createMission();interaction=null;noiseCount=0;invulnerable=1;lastStage='';lastDistance=-1;lastThreat='';growlTime=4;
  player.group.position.set(MISSION.start.x,0,MISSION.start.z);player.group.rotation.y=Math.PI;camera.position.set(MISSION.start.x+.52,1.68,MISSION.start.z+2.8);
  aimBlend=0;camera.fov=58;camera.updateProjectionMatrix();
  player.group.visible=true;phase='playing';resetInputs();
  characterVisuals.animate(player,{phase:0,moving:false,dt:0,snap:true});
  updateCamera(0,true);updatePlayerPose(0,true);
  $('intro').classList.add('hidden');$('end').classList.add('hidden');$('paused').classList.add('hidden');$('route').classList.add('hidden');$('hud').classList.remove('hidden');$('damage').style.opacity=0;
  const fadeOverlay=$('fade-overlay');
  if(fadeOverlay){fadeOverlay.style.display='none';fadeOverlay.classList.add('fade-out');}
  populateDistrict();toast('Sigue la avenida hasta la bifurcación. Ahorra munición.',5);updateHUD(true);window.__gameState=state;
}
function state(detailed=false){return {elapsed:gameTime,population:detailed?enemies.filter(e=>!e.dead).map(e=>({id:e.id,x:e.group.position.x,z:e.group.position.z,kind:e.kind,hp:e.hp,maxHp:e.maxHp,reinforcement:e.reinforcement,name:ENEMY_TYPES[e.kind].name,mode:e.mode})):undefined,obstacles:detailed?obstacles.map(o=>({...o})):undefined,version:'1.0',profile:{...profile,ownedWeapons:[...profile.ownedWeapons],ownedSkins:[...profile.ownedSkins],completedRuns:[...profile.completedRuns],ammo:{...profile.ammo}},profilePersistent,run:{maxHealth:runMaxHealth,speedScale:runSpeedScale,damageScale:runDamageScale},route:missionProgress.route,routeStage:missionProgress.stage,waves:{next:waveProgress.next,pending:waveProgress.pending?{...waveProgress.pending}:null,arrived:[...waveProgress.arrived],spawned:waveSpawned,max:maxReinforcements,lastOrigin:lastWaveOrigin?{...lastWaveOrigin}:null,lastSpawns:lastWaveSpawns.map(e=>({...e}))},joystick:{...joystickSettings},joystickEditing:joystickEditor.isOpen(),reloadTime,reloadTotal,reloadMode,shoveCooldown,shoveTime,lastShove:lastShove?{...lastShove,from:lastShove.from?[...lastShove.from]:null,to:lastShove.to?[...lastShove.to]:null}:null,weapon:activeWeapon.id,skin:activeSkin,runId:currentRunId,lastRunAward,phase,health,ammo,reserve,kills,mission:{...missionProgress,collected:[...missionProgress.collected]},target:missionTarget(missionProgress),interaction:interaction?.id||null,noiseCount,aiming,fov:camera.fov,sensitivity:{...controlSettings},enemies:enemies.filter(e=>!e.dead).length,alerted:enemies.filter(e=>!e.dead&&e.alert>0).length,position:player.group.position.toArray(),camera:camera.position.toArray(),yaw,pitch,viewDirection:camera.getWorldDirection(new V()).toArray(),aimPose:{body:player.upper.rotation.x,rightArm:player.arms[0].rotation.x,leftArm:player.arms[1].rotation.x,gun:player.gunRig.rotation.x},lastShot:lastShot?{...lastShot,from:[...lastShot.from],end:[...lastShot.end],direction:[...lastShot.direction],cameraDirection:[...lastShot.cameraDirection]}:null,visuals:{style:player.metadata?.styleId||activeSkin,resources:characterVisuals.getResourceStats(),blobShadows:enemies.filter(e=>!e.dead&&e.shadow).length+1,shadowMap:renderer.shadowMap.enabled,touch},renderer:{...renderer.info.render}};}
function newRunId(){
  let bits;
  try{bits=[...crypto.getRandomValues(new Uint32Array(3))].map(n=>n.toString(36)).join('-');}
  catch(_){bits=Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2);}
  return `run-${Date.now().toString(36)}-${bits}`;
}
function refreshProfile(){
  if(!profilePersistent)return;
  try{
    const raw=globalThis.localStorage.getItem(ECONOMY_KEY)??globalThis.localStorage.getItem(LEGACY_ECONOMY_KEY);
    profile=raw===null?defaultProfile():normalizeProfile(JSON.parse(raw));
  }catch(_){
    profilePersistent=false;
  }
}
function commitProfile(next){profile=next;profilePersistent=saveProfile(profile);updateProfileUI();}

let currentEnv='night';
let isFpsCamera=false;
let isCrouched=false;
let isSprinting=false;
let isFlashlightOn=true;
let playerSpeed=0;

function turn180(){
  if(phase!=='playing')return;
  yaw=THREE.MathUtils.euclideanModulo(yaw+Math.PI,Math.PI*2);
  player.group.rotation.y=THREE.MathUtils.euclideanModulo(player.group.rotation.y+Math.PI,Math.PI*2);
  updateCamera(0,false);updatePlayerPose(0,true);
  sound('ui');toast('Giro rápido 180°',0.9);
}

function toggleCameraMode(){
  isFpsCamera=!isFpsCamera;
  player.group.visible=!isFpsCamera;
  $('btn-cam')?.classList.toggle('active',isFpsCamera);
  toast(isFpsCamera?'Cámara: Primera Persona (FPS)':'Cámara: Tercera Persona (Detrás del hombro)',1.5);
  updateCamera(0,true);
}

function toggleCrouch(){
  if(phase!=='playing')return;
  isCrouched=!isCrouched;
  if(isCrouched&&isSprinting){
    isSprinting=false;
    $('btn-sprint')?.classList.remove('active');
  }
  $('btn-crouch')?.classList.toggle('active',isCrouched);
  const crouchSpan=$('crouch-label');
  if(crouchSpan)crouchSpan.textContent=isCrouched?'DE PIE':'AGACHARSE';
  sound('ui');
  toast(isCrouched?'Agachado (Sigilo y silencio de pasos)':'De pie',1.2);
}

function toggleSprint(){
  if(phase!=='playing')return;
  isSprinting=!isSprinting;
  if(isSprinting&&isCrouched){
    isCrouched=false;
    $('btn-crouch')?.classList.remove('active');
    const crouchSpan=$('crouch-label');
    if(crouchSpan)crouchSpan.textContent='AGACHARSE';
  }
  $('btn-sprint')?.classList.toggle('active',isSprinting);
  sound('ui');
  toast(isSprinting?'Sprint táctico: MODO CORRER':'Sprint: MODO CAMINAR',1.0);
}

function toggleFlashlight(){
  if(phase!=='playing')return;
  isFlashlightOn=!isFlashlightOn;
  updateFlashlight();
  sound('ui');
  toast(isFlashlightOn?'Linterna táctica: ENCENDIDA':'Linterna: APAGADA',1.0);
}

function updateFlashlight(){
  torch.intensity=isFlashlightOn?(currentEnv.startsWith('day')?0.8:2.8):0;
  $('btn-flashlight')?.classList.toggle('active',isFlashlightOn);
}

const ENV_CYCLES=['day','day_rain','night','night_rain'];
function cycleEnvironment(){
  const idx=ENV_CYCLES.indexOf(currentEnv);
  const next=ENV_CYCLES[(idx+1)%ENV_CYCLES.length];
  setEnvironment(next);
}

function setEnvironment(env){
  currentEnv=env;
  if(env==='day'){
    scene.background.set('#7a8d9a');scene.fog.color.set('#7a8d9a');scene.fog.density=.012;
    moon.color.set('#fff0d4');moon.intensity=2.4;moon.position.set(-20,45,10);
    rain.visible=false;
  }else if(env==='day_rain'){
    scene.background.set('#52616b');scene.fog.color.set('#52616b');scene.fog.density=.015;
    moon.color.set('#d0d8dc');moon.intensity=1.3;moon.position.set(-20,40,10);
    rain.visible=true;
  }else if(env==='night'){
    scene.background.set('#101822');scene.fog.color.set('#101822');scene.fog.density=.018;
    moon.color.set('#c8dcff');moon.intensity=1.8;moon.position.set(-18,32,-24);
    rain.visible=false;
  }else if(env==='night_rain'){
    scene.background.set('#0a0e14');scene.fog.color.set('#0a0e14');scene.fog.density=.022;
    moon.color.set('#6a8298');moon.intensity=1.0;moon.position.set(-18,32,-24);
    rain.visible=true;
  }
  updateFlashlight();
  const badge=$('env-badge');
  if(badge){
    const names={day:'CLIMA: DÍA',day_rain:'CLIMA: LLUVIA DÍA',night:'CLIMA: NOCHE',night_rain:'CLIMA: TORMENTA NOCHE'};
    badge.textContent=names[env]||'CLIMA: NOCHE';
  }
  const descriptions={
    day:'Entorno: Día despejado con sol urbano',
    day_rain:'Entorno: Lluvia diurna sobre asfalto húmedo',
    night:'Entorno: Noche cerrada con luna azulada',
    night_rain:'Entorno: Tormenta nocturna y lluvia torrencial'
  };
  toast(descriptions[env]||'Entorno actualizado',1.8);
}

const MUZZLE_Z={pistol:.43,revolver:.58,smg:.44,shotgun:.5,rifle:.66,assault:.62,sniper:.92,flamethrower:.68};
function applyLoadout(weaponId,skinId){
  activeWeapon=WEAPONS[weaponId]||WEAPONS.pistol;
  const skin=SKINS[skinId]||SKINS.survivor;activeSkin=skin.id;
  characterVisuals.applyPalette(player,skin);
  for(const [id,model]of Object.entries(player.gunModels))model.visible=id===activeWeapon.id;
  player.muzzle.position.z=MUZZLE_Z[activeWeapon.id]??.43;
  const weaponNameEl=$('weapon-name');
  if(weaponNameEl)weaponNameEl.textContent=activeWeapon.name;
}
function updateProfileUI(message=''){
  const walletEl=$('wallet-value');
  if(walletEl)walletEl.textContent=profile.credits;
  const waveEl=$('wave');
  if(waveEl)waveEl.textContent=profile.credits;
  const weapon=WEAPONS[profile.weapon]||WEAPONS.pistol;
  const bought=profile.ammo[weapon.id]||0;
  const stats=runStats(weapon.id,profile.skin);
  const summaryEl=$('loadout-summary');
  if(summaryEl)summaryEl.textContent=`${weapon.name} · ${SKINS[profile.skin].name} · ${weapon.startReserve+bought} balas · ${stats.maxHealth} vitales`;
  const saveNoteEl=$('profile-save-note');
  if(saveNoteEl)saveNoteEl.classList.toggle('hidden',profilePersistent);
  const rewardEl=$('reward-persistence');
  if(rewardEl)rewardEl.textContent=profilePersistent?'Guardado en este navegador o app':'No se pudo guardar: progreso solo para esta sesión';
  shop.render(profile,{persisted:profilePersistent,message});
}
function openShop(){
  if(!['intro','end','playing','paused'].includes(phase))return;
  shopReturnPhase=phase;shopReturnFocus=document.activeElement;refreshProfile();phase='shop';resetInputs();
  $('shop').classList.remove('hidden');updateProfileUI();
  $('shop').querySelector('.shop-close')?.focus({preventScroll:true});
}
function closeShop(){
  if(phase!=='shop')return;
  $('shop').classList.add('hidden');phase=shopReturnPhase;
  applyLoadout(profile.weapon,profile.skin);shopReturnFocus?.focus();
}
function shopAction(kind,id,action){
  if(phase!=='shop')return;
  refreshProfile();
  const result=action==='buy'?purchase(profile,kind,id):action==='equip'?equip(profile,kind,id):null;
  if(!result)return;
  if(result.ok){commitProfile(result.profile);applyLoadout(profile.weapon,profile.skin);}
  updateProfileUI(result.message);
}
function setAim(value){
  if(value&&phase!=='playing')return;
  aiming=Boolean(value);
  $('aim').setAttribute('aria-pressed',String(aiming));
  $('aim').setAttribute('aria-label',aiming?'Dejar de apuntar':'Apuntar');
  $('aim-label').textContent=aiming?'APUNTANDO':'APUNTAR';
  $('hud').classList.toggle('is-aiming',aiming);
}
function syncControls(){
  $('look-sensitivity').value=controlSettings.look;
  $('aim-sensitivity').value=controlSettings.aim;
  $('look-value').textContent=`${controlSettings.look}%`;
  $('aim-value').textContent=`${controlSettings.aim}%`;
}
function updateControls(){
  controlSettings=normalizeControls({look:Number($('look-sensitivity').value),aim:Number($('aim-sensitivity').value)});
  syncControls();
  $('settings-saved').textContent=saveControls(controlSettings)?'Guardado en este dispositivo':'Aplicado para esta sesión';
}
function applyJoystick(){
  const layout=joystickLayout(joystickSettings,innerWidth,innerHeight),el=$('joystick'),knob=$('stick');
  Object.assign(el.style,{left:`${layout.left}px`,top:`${layout.top}px`,bottom:'auto',width:`${layout.size}px`,height:`${layout.size}px`});
  const size=Math.round(layout.size*.36);
  Object.assign(knob.style,{width:`${size}px`,height:`${size}px`,left:`calc(50% - ${size/2}px)`,top:`calc(50% - ${size/2}px)`});
}
function openJoystickEditor(){
  if(phase!=='paused'||joystickEditor.isOpen())return;
  resetInputs();$('paused').classList.add('hidden');joystickEditor.open(joystickSettings);
}
function closeJoystickEditor(){
  if(!joystickEditor.isOpen())return;
  joystickEditor.close();resetInputs();$('paused').classList.remove('hidden');$('edit-joystick').focus({preventScroll:true});
}
function shove(){
  if(phase!=='playing'||shoveCooldown>0)return;
  reloadTime=reloadTotal=0;reloadMode=null;
  shoveTime=COMBAT.shoveAnimation;shoveCooldown=COMBAT.shoveCooldown;
  const p=player.group.position;
  const candidates=enemies.filter(e=>!e.dead&&Math.hypot(e.group.position.x-p.x,e.group.position.z-p.z)<=COMBAT.shoveRange&&!lineBlocked(p,e.group.position))
    .map(e=>({id:e.id,x:e.group.position.x,z:e.group.position.z,hp:e.hp,kind:e.kind}));
  const chosen=chooseShoveTarget({x:p.x,z:p.z,yaw},candidates);
  const target=chosen?enemies.find(e=>e.id===chosen.id):null;
  lastShove={targetId:target?.id||null,hit:Boolean(target),time:gameTime,from:null,to:null};
  if(target){
    const effect=shoveEffect(target.kind),pos=target.group.position;
    lastShove.from=pos.toArray();
    const dx=pos.x-p.x,dz=pos.z-p.z,n=Math.hypot(dx,dz);
    const ux=n>1e-8?dx/n:Math.sin(yaw),uz=n>1e-8?dz/n:-Math.cos(yaw);
    // Small collision-aware steps prevent pushing through thin street furniture.
    const steps=Math.ceil(effect.distance/.07);
    for(let i=0;i<steps;i++)moveEntity(pos,ux*effect.distance/steps,uz*effect.distance/steps,.3);
    target.stagger=Math.max(target.stagger,effect.stagger);target.attack=Math.max(target.attack,effect.stagger);
    lastShove.to=pos.toArray();
    toast(target.kind==='brute'?'El bruto apenas retrocede. ¡Muévete!':'Lo apartaste. Aprovecha para escapar.',1.8);
  }else toast('No hay un infectado al alcance, delante de ti.',1.5);
  sound('hit');makeNoise(6);updateHUD();
}
function reload(){
  if(phase!=='playing'||reloadTime>0||shoveTime>0||ammo===activeWeapon.magazine)return;
  if(reserve<=0){toast('Sin balas de reserva. Busca cajas o evita a los infectados.',2);return;}
  reloadTotal=reloadDuration(activeWeapon.reload,ammo);reloadTime=reloadTotal;
  reloadMode=ammo>0?'manual':'automatic';
  toast(reloadMode==='manual'?'Recarga manual rápida…':'Cargador vacío: recarga automática más lenta…',reloadTotal);
  sound('reload');updateHUD();
}
const shotRay=new THREE.Raycaster();
function visibleInWorld(object){
  for(let parent=object;parent;parent=parent.parent)if(!parent.visible)return false;
  return true;
}
function worldHit(origin,direction,range){
  if(range<=0)return null;
  shotRay.set(origin,direction);shotRay.near=.001;shotRay.far=range;
  const solids=shotBlockers.filter(visibleInWorld),sides=new Map();
  // Ray-only double-sided testing also catches exits from embedded barrels.
  // Restore render materials synchronously, even if an intersection fails.
  for(const object of solids){
    if(!sides.has(object.material)){
      sides.set(object.material,object.material.side);
      object.material.side=THREE.DoubleSide;
    }
  }
  try{return shotRay.intersectObjects(solids,false)[0]||null;}
  finally{for(const [material,side]of sides)material.side=side;}
}
function enemyTargets(){
  return enemies.filter(e=>!e.dead).map(e=>{
    const p=e.group.position,s=e.group.scale;
    return {id:e.id,enemy:e,bounds:{
      min:{x:p.x-.44*s.x,y:p.y+.10*s.y,z:p.z-.44*s.z},
      max:{x:p.x+.44*s.x,y:p.y+(e.kind==='brute'?2.18:2.08)*s.y,z:p.z+.44*s.z}
    }};
  });
}
function traceBullet(origin,direction,range,targets){
  const wall=worldHit(origin,direction,range);
  let distance=wall?wall.distance:range,target=null;
  for(const item of targets){
    const hit=rayBox(origin,direction,item.bounds,range);
    if(hit!==null&&hit<distance-.001){distance=hit;target=item.enemy;}
  }
  return {from:origin.clone(),end:origin.clone().addScaledVector(direction,distance),
    target,impact:target?'enemy':wall?'world':'air',direction:direction.clone()};
}
function traceShot(){
  scene.updateMatrixWorld();
  camera.updateMatrixWorld();
  const origin=camera.position.clone(),view=camera.getWorldDirection(new V());
  const range=aiming?activeWeapon.aimRange:activeWeapon.range;
  const targets=enemyTargets(),viewRange=range+4;
  const wall=worldHit(origin,view,viewRange);
  let point=wall?wall.point.clone():origin.clone().addScaledVector(view,viewRange);
  const candidates=aimCandidates({origin,direction:view,targets,range:viewRange,
    horizontalAssist:aiming?(touch?.16:.12):(touch?.21:.18),
    verticalAssist:aiming?.035:.055});
  for(const candidate of candidates){
    // A reticle on nearby cover must not select an infected behind it.
    if(wall&&wall.distance<candidate.distance-.025)continue;
    const proposed=new V(candidate.point.x,candidate.point.y,candidate.point.z);
    const sight=proposed.clone().sub(origin),distance=sight.length();
    if(distance>.001&&worldHit(origin,sight.normalize(),Math.max(0,distance-.025)))continue;
    point=proposed;break;
  }
  const muzzle=player.muzzle.getWorldPosition(new V());
  const shoulder=player.gunRig.getWorldPosition(new V());
  const barrel=muzzle.clone().sub(shoulder),barrelLength=barrel.length();
  // Camera peeking over a car cannot let a barrel embedded in it shoot through.
  const obstruction=traceBullet(shoulder,barrel.normalize(),barrelLength,targets);
  if(obstruction.impact!=='air')return {...obstruction,view};
  const direction=point.sub(muzzle);
  if(direction.lengthSq()<.0001||direction.dot(view)<=0)direction.copy(view);
  direction.normalize();
  return {...traceBullet(muzzle,direction,range,targets),view};
}
function impactParticles(point,enemyHit){
  const count=enemyHit?16:4;
  for(let i=0;i<count;i++){
    const isBlood=enemyHit&&i>1;
    const color=isBlood?(i%3===0?'#780000':i%2===0?'#b91c1c':'#ef4444'):'#d5c294';
    const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTexture,
      color,transparent:true,depthWrite:false}));
    sprite.position.copy(point);sprite.scale.setScalar(rand(isBlood?.16:.09,isBlood?.38:.22));scene.add(sprite);
    effects.push({object:sprite,life:rand(.25,.5),max:.5,type:isBlood?'blood':'spark',
      velocity:new V(rand(-1.6,1.6),rand(enemyHit?-.1:.2,2),rand(-1.6,1.6))});
  }
}
function shoot(isTap=false){
  if(phase!=='playing'||(shotCooldown>0&&!tapBypassesCooldown(activeWeapon.id,isTap))||reloadTime>0||shoveTime>0)return;
  if(ammo<=0){if(reserve>0)reload();else{shotCooldown=.7;toast('Sin munición. Busca cajas o evita a los infectados.',2);}return;}
  const view=camera.getWorldDirection(new V());
  player.group.rotation.y=Math.atan2(view.x,view.z);
  updatePlayerPose(0,true);

  if(activeWeapon.id==='flamethrower'){
    const muzzlePos=player.muzzle.getWorldPosition(new V());
    for(let f=0;f<8;f++){
      const flame=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTexture,color:f%2?'#ff5500':'#ffaa00',transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));
      flame.position.copy(muzzlePos);flame.scale.setScalar(rand(.2,.6));scene.add(flame);
      const vel=view.clone().multiplyScalar(rand(12,18)).add(new V(rand(-1.5,1.5),rand(-.8,1.2),rand(-1.5,1.5)));
      effects.push({object:flame,life:rand(.25,.45),max:.45,type:'flame',velocity:vel});
    }
    const coneRange=activeWeapon.range||14;
    for(const e of enemies){
      if(e.dead)continue;
      const toE=e.group.position.clone().sub(player.group.position);toE.y=0;
      const dist=toE.length();
      if(dist<coneRange&&toE.normalize().dot(view)>.62){
        const damage=Math.round(activeWeapon.damage*runDamageScale);
        e.hp-=damage;e.stagger=.25;e.flash=.15;
        feedback.hitmarker(e.hp<=0?'kill':'body');
        feedback.damageNumber(e.group.position.clone().add(new V(0,1.3,0)),damage,camera,e.hp<=0?'kill':'body');
        impactParticles(e.group.position.clone().add(new V(0,1.2,0)),true);
        if(e.hp<=0){e.dead=true;e.fade=0;kills++;}
      }
    }
  }

  const pellets=Math.max(1,activeWeapon.pellets||1);
  const spread=activeWeapon.spread||0;
  let primary=null,anyHit=false,anyWorld=false;
  for(let pellet=0;pellet<pellets;pellet++){
    // Each pellet is an independent ray; the first one is the reticle shot.
    if(spread>0&&pellet>0){
      const jitter=new V((Math.random()-.5)*spread,(Math.random()-.5)*spread,(Math.random()-.5)*spread);
      camera.rotateOnWorldAxis(new V(0,1,0),jitter.x);
      camera.rotateX(jitter.y);
      camera.updateMatrixWorld();
    }
    const shot=traceShot(),{from,end,target}=shot;
    if(!primary)primary=shot;
    const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints([from,end]),new THREE.LineBasicMaterial({color:'#ffe4a7',transparent:true,opacity:.9}));scene.add(line);effects.push({object:line,life:.07,max:.07,type:'line'});
    if(target){
      anyHit=true;
      const firstHit=target.hp===target.maxHp;
      const damage=Math.round(activeWeapon.damage*runDamageScale);
      target.hp-=damage;target.stagger=.22;
      // White one-frame flash on the struck enemy.
      target.flash=.09;
      feedback.hitmarker(target.hp<=0?'kill':'body');
      feedback.damageNumber(end,damage,camera,target.hp<=0?'kill':'body');
      feedback.kick(target.hp<=0?3:2.2);
      if(firstHit&&target.hp>0&&(target.kind==='resistant'||target.kind==='brute')){
        toast(`${ENEMY_TYPES[target.kind].name}: aguanta más disparos. Evítalo si puedes.`,2.5);
      }
      moveEntity(target.group.position,shot.direction.x*.13,shot.direction.z*.13,.3);
      impactParticles(end,true);
      if(target.hp<=0){target.dead=true;target.fade=0;kills++;}
    }else if(shot.impact==='world'){anyWorld=true;impactParticles(end,false);}
  }
  const shot0=primary;
  lastShot={from:shot0.from.toArray(),end:shot0.end.toArray(),direction:shot0.direction.toArray(),
    cameraDirection:shot0.view.toArray(),impact:anyHit?'enemy':anyWorld?'world':'air',
    enemyId:null,pellets};
  ammo--;shotCooldown=activeWeapon.cooldown;recoil=activeWeapon.recoil*(aiming?.69:1);muzzleTime=.065;player.muzzle.visible=true;
  sound('shot',0,activeWeapon.id);makeNoise(activeWeapon.noise);
  if(anyHit)sound('hit',0);else if(anyWorld)sound('world',0);
  if(ammo===0&&reserve>0)reload();
  updateHUD();
}
function updateHUD(force=false){
  if(force||health!==lastHealth){$('health').textContent=Math.max(0,Math.ceil(health));$('health-bar').style.width=`${Math.max(0,health/runMaxHealth*100)}%`;$('health-bar').style.background=health<runMaxHealth*.3?'#ef765e':'';$('health-max').textContent=` / ${runMaxHealth}`;lastHealth=health;}
  if(force||ammo!==lastAmmo){$('ammo').textContent=String(ammo).padStart(2,'0');lastAmmo=ammo;}
  $('reserve').textContent=String(reserve).padStart(3,'0');
  if(force||kills!==lastKills){$('kills').textContent=String(kills).padStart(2,'0');lastKills=kills;}
  const stage=missionProgress.stage;
  if(force||stage!==lastStage){
    const target=missionTarget(missionProgress);
    $('objective').textContent=stage==='complete'?'Zona de extracción alcanzada':target?target.label:'Alcanza la zona de extracción';
    lastStage=stage;
  }
  const target=missionTarget(missionProgress);
  if(target){
    const p=player.group.position,dx=target.x-p.x,dz=target.z-p.z;
    const distance=Math.ceil(Math.hypot(dx,dz));
    if(force||distance!==lastDistance){$('mission-distance').textContent=`${distance} m`;lastDistance=distance;}
    const bearing=Math.atan2(dx,-dz)-yaw;
    $('mission-arrow').style.transform=`rotate(${bearing}rad)`;
  }
  const danger=enemies.some(e=>!e.dead&&e.mode==='chase')?'TE HAN VISTO':enemies.some(e=>!e.dead&&e.alert>0)?'TE ESTÁN BUSCANDO':'AVANZA CON CUIDADO';
  if(force||danger!==lastThreat){$('mission-danger').textContent=danger;$('mission-danger').classList.toggle('danger',danger==='TE HAN VISTO');lastThreat=danger;}
  $('ammo').classList.toggle('low-ammo',ammo+reserve<=4);
  interaction=phase==='playing'?nearbyInteraction(player.group.position,missionProgress):null;
  $('interact').classList.toggle('hidden',!interaction);
  if(interaction){$('interact-label').textContent=interaction.kind==='health'&&health>=runMaxHealth?'Salud completa · deja el botiquín':interaction.label;$('interact').disabled=interaction.kind==='health'&&health>=runMaxHealth;}

  $('reload').classList.toggle('reloading',reloadTime>0);
  $('reload-feedback').textContent=reloadTime>0?`${reloadMode==='manual'?'MANUAL':'AUTOMÁTICA'} · ${reloadTime.toFixed(1)} s`:'RECARGA ANTES DE VACIAR';
  $('shove').disabled=shoveCooldown>0;
  $('shove-label').textContent=shoveCooldown>0?`${shoveCooldown.toFixed(1)} s`:'EMPUJAR';
  $('shove').setAttribute('aria-label',shoveCooldown>0?`Empujón recuperándose: ${Math.ceil(shoveCooldown)} segundos`:'Empujar al infectado de delante');
  const pending=waveProgress.pending;
  const waveText=pending?`${waveProgress.next}/${WAVES.length} · ${Math.max(0,Math.ceil(pending.dueAt-gameTime))} s`:`${waveProgress.arrived.length}/${WAVES.length}`;
  if($('wave-count').textContent!==waveText)$('wave-count').textContent=waveText;
  $('wave-label').textContent=pending?'EN CAMINO':'OLEADAS';
  $('wave-status').classList.toggle('incoming',Boolean(pending));

  const classicAmmo=$('classic-ammo');
  if(classicAmmo)classicAmmo.textContent=`${ammo}/${reserve} : ${activeWeapon.name}`;
  const classicEnergy=$('classic-energy');
  if(classicEnergy)classicEnergy.textContent=`${Math.max(0,Math.ceil(health))}/${runMaxHealth} : Energy`;
}
function endGame(victory){
  if(phase!=='playing'||(victory&&missionProgress.stage!=='complete'))return;
  phase='end';
  audioEngine.stopAmbience();
  if(victory){refreshProfile();const settled=rewardExtraction(profile,currentRunId,{supplies:missionProgress.supplies});lastRunAward=settled.awarded;commitProfile(settled.profile);}else lastRunAward=0;
  $('end-reward').textContent=victory?`+${lastRunAward} CRÉDITOS${missionProgress.supplies?` · incluye +${SUPPLIES_BONUS} por suministros`:''}`:'Sin recompensa · tus créditos anteriores se conservan';
  updateProfileUI();resetInputs();$('end').classList.remove('hidden');
  $('interact').classList.add('hidden');
  $('end-title').textContent=victory?'SALISTE DEL DISTRITO':'EL DISTRITO TE RECLAMÓ';
  const restartBtn=$('restart');
  if(restartBtn){
    const span=restartBtn.querySelector('span');
    if(span)span.textContent=victory?'SIGUIENTE MISIÓN / CONTINUAR':'REINTENTAR';
  }
  const routeName=missionProgress.route?(ROUTES[missionProgress.route]||ROUTES.short).name:'sin ruta';
  $('end-detail').textContent=`${kills} infectados eliminados · ${Math.floor(gameTime/60)}:${String(Math.floor(gameTime%60)).padStart(2,'0')} de supervivencia · ${routeName}${victory?` · ${ammo+reserve} balas restantes al salir`:''}`;
  $('objective').textContent=victory?'Extracción completada':'Sin señal';
}
function returnToMainMenu(){
  phase='intro';
  $('end').classList.add('hidden');
  $('hud').classList.add('hidden');
  $('paused').classList.add('hidden');
  $('route').classList.add('hidden');
  $('intro').classList.remove('hidden');
  audioEngine.stopAmbience();
  resetInputs();
}
function pause(){if(joystickEditor.isOpen()){closeJoystickEditor();return;}if(phase==='playing'){phase='paused';$('paused').classList.remove('hidden');resetInputs();$('interact').classList.add('hidden');}else if(phase==='paused'){phase='playing';$('paused').classList.add('hidden');document.activeElement?.blur();}}
function collides(x,z,r=.38){if(x<-10.7||x>10.7||z<-92||z>78)return true;return obstacles.some(o=>Math.abs(x-o.x)<o.rx+r&&Math.abs(z-o.z)<o.rz+r);}
function moveEntity(position,dx,dz,r=.38){if(!collides(position.x+dx,position.z,r))position.x+=dx;if(!collides(position.x,position.z+dz,r))position.z+=dz;}
function movePlayer(position,dx,dz){
  const free=(x,z)=>!collides(x,z)&&!enemies.some(e=>!e.dead&&Math.hypot(x-e.group.position.x,z-e.group.position.z)<.72);
  if(free(position.x+dx,position.z))position.x+=dx;
  if(free(position.x,position.z+dz))position.z+=dz;
}
const cameraTarget=new V();
const cameraForward=new V(),cameraRight=new V(),cameraPivot=new V(),desiredCamera=new V();
function updateCamera(dt,snap=false){
  const p=player.group.position,dir=aimDirection(yaw,pitch);
  cameraForward.set(dir.x,dir.y,dir.z);cameraRight.set(Math.cos(yaw),0,Math.sin(yaw));
  if(isFpsCamera){
    player.group.visible=false;
    const eyeHeight=isCrouched?0.95:1.55;
    desiredCamera.copy(p);
    desiredCamera.y+=eyeHeight;
    desiredCamera.addScaledVector(cameraForward,0.24);
    if(snap)camera.position.copy(desiredCamera);
    else camera.position.lerp(desiredCamera,1-Math.exp(-dt*20));
    cameraTarget.copy(camera.position).addScaledVector(cameraForward,12);
    cameraTarget.y+=recoil*.8;
    camera.lookAt(cameraTarget);camera.updateMatrixWorld();
    return;
  }
  player.group.visible=true;
  cameraPivot.copy(p);cameraPivot.y+=isCrouched?0.92:1.48;
  const downClearance=.6*clamp((-pitch-.6)/.6,0,1);
  const targetArmDistance=2.8-.55*aimBlend;
  const rightOffset=.52+.11*aimBlend+downClearance;

  // Unconstrained desired camera position
  desiredCamera.copy(cameraPivot)
    .addScaledVector(cameraForward,-targetArmDistance)
    .addScaledVector(cameraRight,rightOffset);
  desiredCamera.y=Math.max(p.y+.35,desiredCamera.y+.18+.04*aimBlend+recoil*.35);

  // Spring-Arm Raycast Collision: test ray from pivot to desiredCamera against solids
  const camOffset=desiredCamera.clone().sub(cameraPivot);
  const fullDist=camOffset.length();
  let actualDist=fullDist;

  if(fullDist>0.001){
    camOffset.normalize();
    shotRay.set(cameraPivot,camOffset);
    shotRay.near=0.04;
    shotRay.far=fullDist;
    const solids=shotBlockers.filter(visibleInWorld);
    const hits=shotRay.intersectObjects(solids,false);
    if(hits.length>0){
      // Keep camera in front of the hit surface with safe clearance margin
      actualDist=Math.min(actualDist,Math.max(0.38,hits[0].distance-0.32));
    }
  }

  // Street boundary safety limit so the camera never leaves the playable street
  const testPos=cameraPivot.clone().addScaledVector(camOffset,actualDist);
  testPos.x=clamp(testPos.x,-10.4,10.4);
  testPos.z=clamp(testPos.z,-93.0,76.5);
  testPos.y=Math.max(p.y+.35,testPos.y);
  desiredCamera.copy(testPos);

  // Responsive lerp: if camera is being pushed inward by an obstacle, snap/lerp fast to avoid clipping
  const curDist=camera.position.distanceTo(cameraPivot);
  const lerpFactor=actualDist<curDist?(1-Math.exp(-dt*25)):(1-Math.exp(-dt*9));
  if(snap)camera.position.copy(desiredCamera);
  else camera.position.lerp(desiredCamera,lerpFactor);

  cameraTarget.copy(cameraPivot).addScaledVector(cameraForward,12);
  cameraTarget.y+=recoil*.8;
  camera.lookAt(cameraTarget);
  camera.updateMatrixWorld();
}
function updatePlayerPose(dt,snap=false){
  const view=camera.getWorldDirection(cameraForward);
  const viewPitch=Math.asin(clamp(view.y,-1,1));
  const localYaw=THREE.MathUtils.euclideanModulo(Math.atan2(view.x,view.z)-player.group.rotation.y+Math.PI,Math.PI*2)-Math.PI;
  const progress=reloadTime>0?1-reloadTime/Math.max(.001,reloadTotal):1;
  const push=shoveTime>0?Math.sin((1-shoveTime/COMBAT.shoveAnimation)*Math.PI):0;
  const reloadTarget=reloadTime>0?Math.max(0,Math.min(1,progress*6,(1-progress)*5)):0;
  reloadBlend=snap?reloadTarget:THREE.MathUtils.lerp(reloadBlend,reloadTarget,1-Math.exp(-dt*18));
  const bodyPitch=viewPitch*.3*(1-reloadBlend*.4),armPitch=viewPitch-bodyPitch;
  player.upper.rotation.order='YXZ';player.upper.rotation.x=-bodyPitch+push*.12;
  player.upper.rotation.y=clamp(localYaw,-.8,.8);
  player.upper.position.y=isCrouched?.68:(1.49-player.group.position.y);
  player.group.scale.y=isCrouched?0.82:1.0;
  player.arms[0].rotation.x=-armPitch+reloadBlend*.65-recoil*.7;
  player.arms[1].rotation.x=-armPitch+reloadBlend*.68-recoil*.55-push*.65;
  player.arms[1].rotation.z=reloadBlend*Math.sin(progress*Math.PI)*.12;
  player.gunRig.rotation.x=-armPitch+reloadBlend*.65+push*.4;
  player.gunRig.rotation.z=-reloadBlend*.45;
  player.gun.rotation.x=-recoil*1.3;player.gun.position.y=-reloadBlend*.05;
}
function tick(dt,t){
  const p=player.group.position;
  missionWorld.update({stage:missionProgress.stage,time:t,supplies:missionProgress.supplies,playerPosition:p,collected:missionProgress.collected});
  for(const m of mist)m.position.x+=Math.sin(t*.12+m.position.z)*dt*.04;
  if(rain.visible){
    rain.position.set(p.x,0,p.z);const a=rain.geometry.attributes.position.array;
    for(let i=0;i<rainCount;i++){const j=i*6;a[j+1]-=dt*14;a[j+4]-=dt*14;if(a[j+1]<0){a[j+1]+=20;a[j+4]+=20;}}rain.geometry.attributes.position.needsUpdate=true;
  }
  for(let i=effects.length-1;i>=0;i--){const e=effects[i];e.life-=dt;if(e.velocity){e.object.position.addScaledVector(e.velocity,dt);e.velocity.y-=dt*(e.type==='flame'?1:4);}e.object.material.opacity=clamp(e.life/e.max,0,1);if(e.life<=0){scene.remove(e.object);if(e.type==='line')e.object.geometry.dispose();e.object.material.dispose();effects.splice(i,1);}}
  if(phase==='intro'){
    camera.position.set(8+Math.sin(t*.12)*2,5.8,65);camera.lookAt(-1,1.8,32);player.group.visible=true;
    moon.position.set(-6,28,70);moon.target.position.set(0,1.5,50);
    return;
  }
  if(phase!=='playing')return;
  aimBlend+=((aiming?1:0)-aimBlend)*(1-Math.exp(-dt*12));
  const isSniperAim=aiming&&activeWeapon.id==='sniper';
  const fov=isSniperAim?18:(58-14*aimBlend);
  if(Math.abs(camera.fov-fov)>.005){camera.fov=fov;camera.updateProjectionMatrix();}
  const sniperScope=$('sniper-scope');
  if(sniperScope)sniperScope.classList.toggle('active',isSniperAim);

  gameTime+=dt;invulnerable=Math.max(0,invulnerable-dt);shotCooldown=Math.max(0,shotCooldown-dt);muzzleTime-=dt;player.muzzle.visible=muzzleTime>0;recoil*=Math.exp(-dt*15);
  shoveCooldown=Math.max(0,shoveCooldown-dt);shoveTime=Math.max(0,shoveTime-dt);
  if(statusTime>0){statusTime-=dt;if(statusTime<=0)$('status').classList.remove('visible');}
  if(reloadTime>0){reloadTime=Math.max(0,reloadTime-dt);if(reloadTime===0){const count=Math.min(activeWeapon.magazine-ammo,reserve);ammo+=count;reserve-=count;reloadMode=null;toast('Arma lista',.9);}}
  if(ammo===0&&reserve>0&&reloadTime===0&&shoveTime===0)reload();

  // Update falling window zombies physics
  for(let i=fallingZombies.length-1;i>=0;i--){
    const item=fallingZombies[i];
    if(!item.grounded){
      item.vy-=22*dt;
      item.enemy.group.position.y+=item.vy*dt;
      if(item.enemy.group.position.y<=0){
        item.enemy.group.position.y=0;
        item.grounded=true;
        item.enemy.stagger=1.4;
        impactParticles(item.enemy.group.position.clone().add(new V(0,.2,0)),true);
        sound('world',panFor(item.enemy.group.position));
        sound('growl',panFor(item.enemy.group.position),6);
        fallingZombies.splice(i,1);
      }
    }
  }
  checkWindowDrops();

  let mx=stickX+(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);
  let my=-stickY+(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0);
  const norm=Math.hypot(mx,my);if(norm>1){mx/=norm;my/=norm;}
  const forward=new V(Math.sin(yaw),0,-Math.cos(yaw)),right=new V(Math.cos(yaw),0,Math.sin(yaw));
  const movement=forward.clone().multiplyScalar(my).addScaledVector(right,mx);
  const moving=movement.length()>.05;
  const sprintWanted=(isSprinting||keys.has('ShiftLeft')||keys.has('ShiftRight'))&&ammo>0&&!aiming&&!isCrouched;
  let targetSpeed=0;
  if(moving){
    targetSpeed=(sprintWanted?5.2:3.2)*(my<-.3?.8:1)*(aiming?.62:1)*runSpeedScale;
    if(isCrouched)targetSpeed*=.50;
  }
  playerSpeed=THREE.MathUtils.lerp(playerSpeed,targetSpeed,1-Math.exp(-dt*9));
  movePlayer(p,movement.x*playerSpeed*dt,movement.z*playerSpeed*dt);
  if(moving){
    walkTime+=dt*(isCrouched?4.2:(sprintWanted?11.5:7.4));
    stepTime-=dt;
    if(stepTime<=0){
      if(!isCrouched){sound('step',0,aiming?.55:1);if(sprintWanted)makeNoise(18);}
      stepTime=sprintWanted?.24:(isCrouched?.62:.42);
    }
  }else stepTime=0;
  const desired=Math.atan2(forward.x,forward.z);
  const angle=THREE.MathUtils.euclideanModulo(desired-player.group.rotation.y+Math.PI,Math.PI*2)-Math.PI;
  player.group.rotation.y+=angle*Math.min(1,dt*16);
  characterVisuals.animate(player,{phase:walkTime,moving,dt});
  player.group.position.y=(Math.abs(p.x)>9?.10:0)+(moving?Math.abs(Math.sin(walkTime))*.018:0);
  groundCharacter(player);

  updateWaves();
  for(let i=enemies.length-1;i>=0;i--){
    const e=enemies[i];
    if(e.dead){if(e.shadow)e.shadow.visible=false;e.fade+=dt;e.group.rotation.z=THREE.MathUtils.lerp(e.group.rotation.z,1.55,Math.min(1,dt*6));e.group.position.y=-Math.min(.6,e.fade*.16);if(e.fade>4.5){scene.remove(e.group);enemies.splice(i,1);}continue;}
    const toPlayer=p.clone().sub(e.group.position);toPlayer.y=0;const dist=toPlayer.length();
    e.group.visible=dist<36;
    e.distant.visible=dist>19;
    for(const detail of e.details)detail.visible=dist<=19;
    const facing=new V(Math.sin(e.group.rotation.y),0,Math.cos(e.group.rotation.y));
    const soundDist=sprintWanted?22:(isCrouched?2.5:9);
    const hearsPlayer=dist<soundDist&&(sprintWanted||!isCrouched)&&!lineBlocked(e.group.position,p);
    const seesPlayer=dist<3||(dist<18&&toPlayer.clone().normalize().dot(facing)>.15&&!lineBlocked(e.group.position,p));
    if(seesPlayer||hearsPlayer){e.lastKnown.copy(p);e.alert=6;e.mode='chase';}
    else{e.alert=Math.max(0,e.alert-dt);e.mode=e.alert>0?'investigate':'idle';}
    e.wanderTimer-=dt;
    if(e.wanderTimer<=0){e.wander.copy(e.home).add(new V(rand(-2,2),0,rand(-2.5,2.5)));e.wanderTimer=rand(4,8);}
    const target=e.alert>0?e.lastKnown:e.wander;
    const dir=target.clone().sub(e.group.position);dir.y=0;const destinationDistance=dir.length();dir.normalize();
    const separation=new V();
    for(const other of enemies){
      if(other===e||other.dead)continue;
      const dx=e.group.position.x-other.group.position.x,dz=e.group.position.z-other.group.position.z,n=Math.hypot(dx,dz);
      if(n<.9&&n>.01){const k=(.9-n)/n*.8;separation.x+=dx*k;separation.z+=dz*k;}
    }
    e.stagger=Math.max(0,e.stagger-dt);
    // One-frame white flash on the struck enemy, then back to its palette.
    if(e.flash>0){
      e.flash=Math.max(0,e.flash-dt);
      const lit=e.flash>0;
      for(const detail of e.details){if(detail.material&&detail.material.emissive)detail.material.emissive.setHex(lit?0xffffff:0x000000);}
    }
    const walking=destinationDistance>.55&&(dist>1||e.alert===0);
    if(walking){
      const step=dir.clone().add(separation).normalize().multiplyScalar(e.speed*dt*(e.alert>0?1:.28)*(e.stagger>0?.18:1));
      const before=e.group.position.clone();moveEntity(e.group.position,step.x,step.z,.3);
      if(e.group.position.distanceToSquared(before)<.00001)moveEntity(e.group.position,(e.group.position.x>0?-1:1)*dt*e.speed,step.z,.3);
      const desired=Math.atan2(dir.x,dir.z);const turn=THREE.MathUtils.euclideanModulo(desired-e.group.rotation.y+Math.PI,Math.PI*2)-Math.PI;
      e.group.rotation.y+=turn*Math.min(1,dt*4);
      e.anim+=dt*e.speed*(e.alert>0?5.5:2.2);
    }
    characterVisuals.animate(e,{phase:e.anim,moving:walking,dt});
    e.arms[0].rotation.x=(e.alert>0?-1.12:-.2)+Math.sin(e.anim*.5)*.12;e.arms[1].rotation.x=(e.alert>0?-1.18:-.25)-Math.sin(e.anim*.5)*.12;e.torso.rotation.z=Math.sin(e.anim*.5)*.035;
    groundCharacter(e);
    e.attack-=dt;
    if(dist<1.55&&e.attack<=0&&e.stagger<=0&&invulnerable<=0&&!lineBlocked(e.group.position,p)){
      health-=12;e.attack=1.15;invulnerable=.6;damageFade=.55;sound('hurt',panFor(e.group.position));feedback.kick(3);
      if(health<=0){health=0;endGame(false);break;}
    }
  }
  growlTime-=dt;
  if(growlTime<=0){
    const near=enemies.filter(e=>!e.dead&&e.alert>0&&e.group.position.distanceTo(p)<14);
    if(near.length){
      // Pan by the nearest threat so a growl from behind is audible behind you.
      const closest=near.reduce((a,b)=>a.group.position.distanceTo(p)<b.group.position.distanceTo(p)?a:b);
      sound('growl',panFor(closest.group.position),closest.group.position.distanceTo(p));
    }
    growlTime=rand(3,6);
  }
  damageFade=Math.max(0,damageFade-dt);$('damage').style.opacity=damageFade;
  updateCamera(dt);updatePlayerPose(dt);
  // Screen-space feedback: hitmarker decay, floating numbers, camera shake.
  const shakeOffset=feedback.update(dt);
  canvas.style.transform=shakeOffset.x||shakeOffset.y?`translate(${shakeOffset.x.toFixed(1)}px,${shakeOffset.y.toFixed(1)}px)`:'';
  // Shooting now uses this frame's camera, not last frame's horizontal heading.
  if(fireHeld||keys.has('Space'))shoot();
  torch.position.copy(p).add(new V(0,1.7,0));torch.target.position.copy(cameraTarget);
  moon.position.set(p.x-14,28,p.z-20);moon.target.position.copy(p);
  updateHUD();
}

// Debug logging system for HUD touch buttons and interactions
window.__hudTouchLogs = window.__hudTouchLogs || [];
function logTouchDebug(action, btnId, details = {}) {
  const timestamp = new Date().toISOString().slice(11, 23);
  const entry = { time: timestamp, action, btnId, ...details };
  window.__hudTouchLogs.push(entry);
  if (window.__hudTouchLogs.length > 80) window.__hudTouchLogs.shift();
  const detailStr = Object.keys(details).length ? ` | ${JSON.stringify(details)}` : '';
  console.log(`[HUD_TOUCH_DEBUG] [${action}] #${btnId}${detailStr}`);
}

// Window test hook to simulate or verify HUD button responses programmatically
window.__testHudButton = function(btnId) {
  const el = document.getElementById(btnId);
  if (!el) {
    console.warn(`[HUD_TOUCH_DEBUG] Elemento #${btnId} no encontrado en el DOM.`);
    return false;
  }
  console.log(`[HUD_TOUCH_DEBUG] Simulando evento de toque/click en #${btnId}...`);
  el.dispatchEvent(new CustomEvent('click', { bubbles: true, cancelable: true }));
  return true;
};

// Rock-solid mobile button activation: triggers on release, debounced, zero focus outline, instant 120ms visual feedback
function onButtonPress(el, handler) {
  if (!el) return;
  const btnId = el.id || el.getAttribute('aria-label') || el.className || 'button';
  el.style.pointerEvents = 'auto';

  // Log touch button registration & verify computed styles (z-index, pointer-events)
  const computed = typeof window !== 'undefined' && window.getComputedStyle ? window.getComputedStyle(el) : null;
  logTouchDebug('INITIALIZE', btnId, {
    zIndex: computed ? computed.zIndex : el.style.zIndex,
    pointerEvents: computed ? computed.pointerEvents : el.style.pointerEvents,
    touchAction: computed ? computed.touchAction : el.style.touchAction
  });

  let touchedTime = 0;
  let pulseTimer = null;
  let startX = 0, startY = 0;

  const pressDown = (e, source) => {
    el.classList.add('touch-pressed');
    clearTimeout(pulseTimer);
    if (e && e.touches && e.touches[0]) {
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
    }
    logTouchDebug('DOWN', btnId, { source, x: Math.round(startX), y: Math.round(startY) });
  };

  const pressRelease = () => {
    el.classList.add('touch-pressed');
    clearTimeout(pulseTimer);
    pulseTimer = setTimeout(() => {
      el.classList.remove('touch-pressed');
    }, 120);
  };

  const cancelPress = (reason) => {
    clearTimeout(pulseTimer);
    el.classList.remove('touch-pressed');
    logTouchDebug('CANCEL', btnId, { reason });
  };

  const trigger = (e, eventType) => {
    const now = Date.now();
    if (now - touchedTime < 280) {
      logTouchDebug('DEBOUNCE', btnId, { eventType, intervalMs: now - touchedTime });
      return;
    }
    touchedTime = now;
    pressRelease();
    if (e) {
      if (e.stopPropagation) e.stopPropagation();
      if (e.preventDefault && e.cancelable) e.preventDefault();
    }
    if (el.blur) el.blur();
    logTouchDebug('TRIGGER_ACTION', btnId, { eventType });
    try {
      handler(e);
    } catch (err) {
      console.error(`[HUD_TOUCH_DEBUG] [ERROR] Fallo al ejecutar acción de #${btnId}:`, err);
    }
  };

  el.addEventListener('touchstart', e => {
    logTouchDebug('TOUCHSTART', btnId, {
      touches: e.touches ? e.touches.length : 1,
      x: e.touches && e.touches[0] ? Math.round(e.touches[0].clientX) : null,
      y: e.touches && e.touches[0] ? Math.round(e.touches[0].clientY) : null
    });
    pressDown(e, 'touchstart');
  }, { passive: true });

  el.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'touch') {
      logTouchDebug('POINTERDOWN', btnId, { pointerType: e.pointerType });
      pressDown(e, `pointerdown:${e.pointerType}`);
    }
  }, { passive: true });

  el.addEventListener('touchend', e => {
    let dx = 0, dy = 0;
    if (e.changedTouches && e.changedTouches[0]) {
      dx = e.changedTouches[0].clientX - startX;
      dy = e.changedTouches[0].clientY - startY;
      if (Math.hypot(dx, dy) > 35) {
        cancelPress(`drag_exceeded:${Math.round(Math.hypot(dx, dy))}px`);
        return;
      }
    }
    logTouchDebug('TOUCHEND', btnId, { dx: Math.round(dx), dy: Math.round(dy) });
    trigger(e, 'touchend');
  }, { passive: false });

  el.addEventListener('touchcancel', () => cancelPress('touchcancel'), { passive: true });

  el.addEventListener('pointerup', e => {
    if (e.pointerType !== 'touch') {
      logTouchDebug('POINTERUP', btnId, { pointerType: e.pointerType });
      trigger(e, `pointerup:${e.pointerType}`);
    }
  }, { passive: true });

  el.addEventListener('pointercancel', () => cancelPress('pointercancel'), { passive: true });

  el.addEventListener('click', e => {
    logTouchDebug('CLICK', btnId, { isTrusted: e ? e.isTrusted : true });
    trigger(e, 'click');
  });
}

// Fire button with immediate touch & pointer down, continuous automatic burst, and clean release
const fireBtn = $('fire');
fireBtn.style.pointerEvents = 'auto';
const fireComputed = typeof window !== 'undefined' && window.getComputedStyle ? window.getComputedStyle(fireBtn) : null;
logTouchDebug('INITIALIZE', 'fire', {
  zIndex: fireComputed ? fireComputed.zIndex : fireBtn.style.zIndex,
  pointerEvents: fireComputed ? fireComputed.pointerEvents : fireBtn.style.pointerEvents
});

function startFire(e) {
  logTouchDebug('START_FIRE', 'fire', {
    type: e ? e.type : 'manual',
    pointerType: e ? e.pointerType : undefined
  });
  if (phase !== 'playing') return;
  if (e) {
    if (e.preventDefault && e.cancelable) e.preventDefault();
    if (e.stopPropagation) e.stopPropagation();
  }
  fireBtn.classList.add('touch-pressed');
  fireHeld = true;
  shoot(true);
}
function stopFire(e) {
  logTouchDebug('STOP_FIRE', 'fire', { type: e ? e.type : 'manual' });
  if (e) {
    if (e.preventDefault && e.cancelable) e.preventDefault();
    if (e.stopPropagation) e.stopPropagation();
  }
  fireHeld = false;
  firePointerId = null;
  setTimeout(() => {
    fireBtn.classList.remove('touch-pressed');
  }, 60);
  if (fireBtn.blur) fireBtn.blur();
}
fireBtn.addEventListener('pointerdown', e => {
  if (e.pointerType === 'mouse' && e.button !== 0) return;
  firePointerId = e.pointerId;
  try { fireBtn.setPointerCapture(e.pointerId); } catch (_) {}
  startFire(e);
});
fireBtn.addEventListener('touchstart', startFire, { passive: false });
for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) fireBtn.addEventListener(type, stopFire);
fireBtn.addEventListener('touchend', stopFire, { passive: false });
fireBtn.addEventListener('touchcancel', stopFire, { passive: false });
window.addEventListener('pointerup', stopFire);
window.addEventListener('touchend', stopFire);

// Mobile touch combat actions
onButtonPress($('shove'), shove);
onButtonPress($('edit-joystick'), openJoystickEditor);
onButtonPress($('interact'), interact);
onButtonPress($('aim'), () => setAim(!aiming));
onButtonPress($('reload'), reload);
onButtonPress($('btn-180'), turn180);
onButtonPress($('btn-cam'), toggleCameraMode);
onButtonPress($('btn-crouch'), toggleCrouch);
onButtonPress($('btn-sprint'), toggleSprint);
onButtonPress($('btn-flashlight'), toggleFlashlight);
onButtonPress($('btn-env'), cycleEnvironment);
onButtonPress($('start'), start);
onButtonPress($('restart'), start);
onButtonPress($('end-menu'), returnToMainMenu);
onButtonPress($('pause'), pause);
onButtonPress($('resume'), pause);
onButtonPress($('settings'), () => { if (phase === 'playing') pause(); });
onButtonPress($('sound'), () => {
  soundOn = !soundOn;
  $('sound').classList.toggle('muted', !soundOn);
  $('sound').setAttribute('aria-label', soundOn ? 'Silenciar sonido' : 'Activar sonido');
  $('sound').title = soundOn ? 'Sonido activado' : 'Sonido desactivado';
});
onButtonPress($('fullscreen'), () => {
  if (document.fullscreenElement) document.exitFullscreen?.();
  else document.documentElement.requestFullscreen?.().catch(() => {});
});
onButtonPress($('center-look'), () => { pitch = 0; updateCamera(0, true); updatePlayerPose(0, true); });
onButtonPress($('reset-controls'), () => { controlSettings = { ...DEFAULT_CONTROLS }; syncControls(); updateControls(); });

$('look-sensitivity').addEventListener('input', updateControls);
$('aim-sensitivity').addEventListener('input', updateControls);
syncControls();

// Virtual analog movement joystick with dual Touch/Pointer multitouch tracking
const joyEl = $('joystick');
const stickEl = $('stick');
joyEl.style.pointerEvents = 'auto';
logTouchDebug('INITIALIZE', 'joystick', {
  pointerEvents: 'auto',
  zIndex: 30
});
let joyId = null, joyCenter = { x: 0, y: 0 };

function handleJoyStart(e) {
  if (phase !== 'playing' || joyId !== null) return;
  if (e.stopPropagation) e.stopPropagation();
  if (e.cancelable && e.preventDefault) e.preventDefault();
  const point = e.touches ? e.touches[0] : e;
  joyId = e.pointerId !== undefined ? e.pointerId : (point.identifier !== undefined ? point.identifier : 1);
  logTouchDebug('JOYSTICK_START', 'joystick', {
    type: e.type,
    joyId,
    x: point.clientX ? Math.round(point.clientX) : 0,
    y: point.clientY ? Math.round(point.clientY) : 0
  });
  if (e.pointerId && joyEl.setPointerCapture) {
    try { joyEl.setPointerCapture(e.pointerId); } catch (_) {}
  }
  const r = joyEl.getBoundingClientRect();
  joyCenter = { x: r.x + r.width / 2, y: r.y + r.height / 2 };
  handleJoyMove(e);
}

function handleJoyMove(e) {
  if (phase !== 'playing' || joyId === null) return;
  let clientX = 0, clientY = 0, found = false;
  if (e.touches) {
    for (let i = 0; i < e.touches.length; i++) {
      if (e.touches[i].identifier === joyId || joyId === 1) {
        clientX = e.touches[i].clientX;
        clientY = e.touches[i].clientY;
        found = true;
        break;
      }
    }
  }
  if (!found) {
    if (e.pointerId !== undefined && e.pointerId !== joyId) return;
    clientX = e.clientX;
    clientY = e.clientY;
  }
  if (e.cancelable && e.preventDefault) e.preventDefault();
  if (e.stopPropagation) e.stopPropagation();

  const dx = clientX - joyCenter.x;
  const dy = clientY - joyCenter.y;
  const r = joyEl.getBoundingClientRect().width * 0.32;
  const n = Math.hypot(dx, dy);
  const k = n > r ? r / n : 1;
  stickX = (dx * k) / r;
  stickY = (dy * k) / r;
  stickEl.style.transform = `translate(${dx * k}px,${dy * k}px)`;
}

function handleJoyEnd(e) {
  if (joyId === null) return;
  if (e && e.touches && e.touches.length > 0) {
    let stillThere = false;
    for (let i = 0; i < e.touches.length; i++) {
      if (e.touches[i].identifier === joyId) { stillThere = true; break; }
    }
    if (stillThere) return;
  }
  logTouchDebug('JOYSTICK_END', 'joystick', { type: e ? e.type : 'manual' });
  joyId = null;
  stickX = 0;
  stickY = 0;
  stickEl.style.transform = 'translate(0px,0px)';
}

joyEl.addEventListener('pointerdown', handleJoyStart);
joyEl.addEventListener('touchstart', handleJoyStart, { passive: false });
joyEl.addEventListener('pointermove', handleJoyMove);
window.addEventListener('pointermove', handleJoyMove);
window.addEventListener('touchmove', handleJoyMove, { passive: false });
joyEl.addEventListener('pointerup', handleJoyEnd);
joyEl.addEventListener('pointercancel', handleJoyEnd);
joyEl.addEventListener('lostpointercapture', handleJoyEnd);
joyEl.addEventListener('touchend', handleJoyEnd, { passive: false });
joyEl.addEventListener('touchcancel', handleJoyEnd, { passive: false });
window.addEventListener('pointerup', handleJoyEnd);
window.addEventListener('touchend', handleJoyEnd);

// Fullscreen camera look tracking
let lookId = null, lastLookX = 0, lastLookY = 0, rightAimPointer = null;

function handleLookStart(e) {
  if (phase !== 'playing' || lookId !== null) return;
  if (e.pointerType === 'mouse' && e.button === 2) {
    rightAimPointer = e.pointerId;
    setAim(true);
  }
  const point = e.touches ? e.touches[0] : e;
  lookId = e.pointerId !== undefined ? e.pointerId : (point.identifier !== undefined ? point.identifier : 2);
  lastLookX = point.clientX;
  lastLookY = point.clientY;
  if (e.pointerId && canvas.setPointerCapture) {
    try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
  }
}

function handleLookMove(e) {
  if (phase !== 'playing' || lookId === null) return;
  let clientX = 0, clientY = 0, found = false;
  if (e.touches) {
    for (let i = 0; i < e.touches.length; i++) {
      if (e.touches[i].identifier === lookId || lookId === 2) {
        clientX = e.touches[i].clientX;
        clientY = e.touches[i].clientY;
        found = true;
        break;
      }
    }
  }
  if (!found) {
    if (e.pointerId !== undefined && e.pointerId !== lookId) return;
    clientX = e.clientX;
    clientY = e.clientY;
  }
  const dx = clientX - lastLookX;
  const dy = clientY - lastLookY;
  lastLookX = clientX;
  lastLookY = clientY;
  const next = applyLook({ yaw, pitch }, dx, dy, aiming ? controlSettings.aim : controlSettings.look);
  yaw = next.yaw;
  pitch = next.pitch;
}

function handleLookEnd(e) {
  if (e && e.pointerId === rightAimPointer) {
    rightAimPointer = null;
    setAim(false);
  }
  if (lookId === null) return;
  if (e && e.touches && e.touches.length > 0) {
    let stillThere = false;
    for (let i = 0; i < e.touches.length; i++) {
      if (e.touches[i].identifier === lookId) { stillThere = true; break; }
    }
    if (stillThere) return;
  }
  lookId = null;
}

canvas.addEventListener('pointerdown', handleLookStart);
canvas.addEventListener('touchstart', handleLookStart, { passive: true });
canvas.addEventListener('pointermove', handleLookMove);
window.addEventListener('pointermove', handleLookMove);
window.addEventListener('touchmove', handleLookMove, { passive: true });
canvas.addEventListener('pointerup', handleLookEnd);
canvas.addEventListener('pointercancel', handleLookEnd);
canvas.addEventListener('lostpointercapture', handleLookEnd);
canvas.addEventListener('touchend', handleLookEnd);
canvas.addEventListener('touchcancel', handleLookEnd);
window.addEventListener('pointerup', handleLookEnd);
window.addEventListener('touchend', handleLookEnd);
function resetInputs(){
  fireHeld=false;firePointerId=null;stickX=stickY=0;keys.clear();lookId=joyId=rightAimPointer=null;
  setAim(false);
  $('stick').style.transform='translate(0px,0px)';
  for(const el of [canvas,$('joystick'),$('fire')]){
    // Captures naturally release on pointer-up; clearing ownership above also
    // makes delayed move/cancel events harmless after pause or restart.
    el.blur();
  }
}
window.addEventListener('keydown',e=>{
  if(e.code==='Escape'&&!e.repeat){if(joystickEditor.isOpen())closeJoystickEditor();else if(phase==='shop')closeShop();else pause();return;}
  if(phase!=='playing'||e.target.closest?.('input,select,textarea'))return;
  if(e.repeat&&!keys.has(e.code))return;
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
  keys.add(e.code);
  if(e.code==='Space'&&!e.repeat)shoot(true);
  if(e.code==='KeyV'&&!e.repeat)shove();
  if(e.code==='KeyR')reload();
  if(e.code==='KeyC'&&!e.repeat)setAim(!aiming);
  if(e.code==='KeyQ')yaw+=.1;
  if(e.code==='KeyE')yaw-=.1;
  if(e.code==='KeyX'&&!e.repeat)turn180();
  if(e.code==='KeyZ'&&!e.repeat)toggleCrouch();
  if(e.code==='KeyT'&&!e.repeat)toggleCameraMode();
  if(e.code==='KeyF'&&!e.repeat)interact();
});
window.addEventListener('keyup',e=>keys.delete(e.code));
window.addEventListener('blur',()=>{keys.clear();fireHeld=false;stickX=stickY=0;if(phase==='playing')pause();});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&phase==='playing')pause();});
window.addEventListener('contextmenu',e=>e.preventDefault());
window.addEventListener('resize',()=>{resetInputs();applyJoystick();camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
const joystickEditor=createJoystickEditor({container:$('joystick-editor'),onChange:value=>{joystickSettings=normalizeJoystick(value);resetInputs();applyJoystick();},onClose:closeJoystickEditor});
applyJoystick();
const shop=createShop({container:$('shop'),weapons:WEAPONS,skins:SKINS,attachments:ATTACHMENTS,onAction:shopAction,onClose:closeShop});
onButtonPress($('intro-shop'), openShop);
onButtonPress($('intro-continue'), start);
onButtonPress($('classic-calc'), openShop);
onButtonPress($('end-shop'), openShop);
onButtonPress($('route-short'), () => chooseRoute('short'));
onButtonPress($('route-long'), () => chooseRoute('long'));
// Standard touch joystick ready for immediate gameplay without blocking view
document.addEventListener('distrito-back',()=>{if(phase==='shop')closeShop();});
// Test-only hook: software-GL headless runs advance the clock ~50x slower than
// real time, so the harness needs to place the player instead of walking there.
// It exists only when the page is opened with ?debug=1.
if(new URLSearchParams(location.search).has('debug')){
  window.__debugTeleport=(x,z)=>{player.group.position.set(x,0,z);updateCamera(0,true);updateHUD(true);};
  // Advance the simulation deterministically: software GL renders ~45x slower
  // than real time, so wall-clock waits cannot exercise movement or aiming.
  window.__debugAdvance=(seconds)=>{
    const step=1/60;
    for(let t=0;t<seconds;t+=step){elapsed+=step;tick(step,elapsed);}
    return {elapsed:gameTime,position:player.group.position.toArray(),fov:camera.fov};
  };
}
window.addEventListener('storage',e=>{if(e.key===ECONOMY_KEY&&profilePersistent){refreshProfile();updateProfileUI();if(phase!=='playing'&&phase!=='paused')applyLoadout(profile.weapon,profile.skin);}});
applyLoadout(profile.weapon,profile.skin);updateProfileUI();
window.__gameState=state;
$('loading').textContent='Nuevos personajes · 4 atuendos · Conserva tus compras';$('start').disabled=false;
let lastRenderW=0,lastRenderH=0;
function checkCanvasResize(){
  const w=window.innerWidth||document.documentElement.clientWidth||0;
  const h=window.innerHeight||document.documentElement.clientHeight||0;
  if(w>0&&h>0&&(w!==lastRenderW||h!==lastRenderH)){
    lastRenderW=w;lastRenderH=h;
    camera.aspect=w/h;
    camera.updateProjectionMatrix();
    renderer.setSize(w,h,false);
    applyJoystick();
  }
}
let elapsed=0;
function frame(){
  requestAnimationFrame(frame);
  checkCanvasResize();
  const dt=Math.min(clock.getDelta(),.045);elapsed+=dt;tick(dt,elapsed);
  if(phase!=='shop')renderer.render(scene,camera);
}
frame();
